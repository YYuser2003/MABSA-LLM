import json
import glob
import os

print('=' * 80)
print('         MASTER EXPERIMENTAL MATRIX: ALL BENCHMARKS & CONDITIONS')
print('=' * 80)

print('\n' + '=' * 80)
print('SECTION 1: TARGET-GUIDED / GIVEN ENTITIES BENCHMARK (TSC STANDARD)')
print('(Entity extraction is strictly locked 100%, isolating pure sentiment reasoning)')
print('=' * 80)

gem_summary = json.load(open('outputs/gemini_benchmark/benchmark_summary.json'))
g3_15 = json.load(open('outputs/g3_benchmark/metrics_g3_max2_twitter2015_test.json'))
g3_17 = json.load(open('outputs/g3_benchmark/metrics_g3_max2_twitter2017_test.json'))

for ds, g3_m in [('twitter2015', g3_15), ('twitter2017', g3_17)]:
    print(f'\n----------------------------- {ds.upper()} (TEST SET) -----------------------------')
    b0_tg_t = json.load(open(f'outputs/b0_targeted_text_only_{ds}_test_metrics.json'))
    b0_tg_mm = json.load(open(f'outputs/b0_targeted_multimodal_{ds}_test_metrics.json'))
    b1_tg_t = json.load(open(f'outputs/b1_targeted_text_only_{ds}_test_metrics.json'))
    b1_tg_mm = json.load(open(f'outputs/b1_targeted_multimodal_{ds}_test_metrics.json'))
    g0 = gem_summary[ds]['text']
    g1 = gem_summary[ds]['multimodal']
    
    rows = [
        ("B0 (Qwen-VL Zero-Shot)", "Text-Only", b0_tg_t['accuracy'], b0_tg_t['macro_f1'], b0_tg_t['class_metrics']['POS']['f1-score'], b0_tg_t['class_metrics']['NEG']['f1-score'], b0_tg_t['class_metrics']['NEU']['f1-score']),
        ("B0 (Qwen-VL Zero-Shot)", "Multimodal", b0_tg_mm['accuracy'], b0_tg_mm['macro_f1'], b0_tg_mm['class_metrics']['POS']['f1-score'], b0_tg_mm['class_metrics']['NEG']['f1-score'], b0_tg_mm['class_metrics']['NEU']['f1-score']),
        ("B1 (Qwen-VL Direct SFT)", "Text-Only", b1_tg_t['accuracy'], b1_tg_t['macro_f1'], b1_tg_t['class_metrics']['POS']['f1-score'], b1_tg_t['class_metrics']['NEG']['f1-score'], b1_tg_t['class_metrics']['NEU']['f1-score']),
        ("B1 (Qwen-VL Direct SFT)", "Multimodal", b1_tg_mm['accuracy'], b1_tg_mm['macro_f1'], b1_tg_mm['class_metrics']['POS']['f1-score'], b1_tg_mm['class_metrics']['NEG']['f1-score'], b1_tg_mm['class_metrics']['NEU']['f1-score']),
        ("G0 (Gemini 3.8 Flash)", "Text-Only", g0['accuracy'], g0['macro_f1'], g0['class_metrics']['POS']['f1-score'], g0['class_metrics']['NEG']['f1-score'], g0['class_metrics']['NEU']['f1-score']),
        ("G1 (Gemini 3.8 Flash)", "Multimodal", g1['accuracy'], g1['macro_f1'], g1['class_metrics']['POS']['f1-score'], g1['class_metrics']['NEG']['f1-score'], g1['class_metrics']['NEU']['f1-score']),
        ("G3 (Active Visual Reasoning)", "Active Query", g3_m['tsc_benchmark_metrics']['accuracy_final'], g3_m['tsc_benchmark_metrics']['macro_f1_final'], g3_m['tsc_benchmark_metrics']['class_metrics_final']['POS']['f1-score'], g3_m['tsc_benchmark_metrics']['class_metrics_final']['NEG']['f1-score'], g3_m['tsc_benchmark_metrics']['class_metrics_final']['NEU']['f1-score']),
    ]
    
    header = f"{'Model & Paradigm':<30} | {'Condition':<13} | {'Acc (%)':<8} | {'Macro-F1':<8} | {'POS F1':<8} | {'NEG F1':<8} | {'NEU F1':<8}"
    print(header)
    print('-' * len(header))
    for r in rows:
        print(f"{r[0]:<30} | {r[1]:<13} | {r[2]:<8.2f} | {r[3]:<8.2f} | {r[4]:<8.2f} | {r[5]:<8.2f} | {r[6]:<8.2f}")

print('\n' + '=' * 80)
print('SECTION 2: OPEN EXTRACTION BENCHMARK (JOINT ATE + ASC)')
print('(Requires extracting aspect span boundaries and predicting sentiment simultaneously)')
print('=' * 80)

for ds in ['twitter2015', 'twitter2017']:
    print(f'\n----------------------------- {ds.upper()} (TEST SET) -----------------------------')
    b0_mm = json.load(open(f'outputs/b0_zeroshot_{ds}_test_metrics.json'))
    b0_t = json.load(open(f'outputs/b0_textonly_{ds}_test_metrics.json'))
    b1_mm = json.load(open(f'outputs/b1_direct_sft_{ds}_test_metrics.json'))
    b1_t = json.load(open(f'outputs/b1_textonly_{ds}_test_metrics.json'))
    
    rows = [
        ("B0 Zero-Shot", "Text-Only", b0_t['pair_metrics']['pair_precision'], b0_t['pair_metrics']['pair_recall'], b0_t['pair_metrics']['pair_f1'], b0_t['pair_metrics']['aspect_f1'], b0_t['pair_metrics']['sentiment_acc_on_matched']),
        ("B0 Zero-Shot", "Multimodal", b0_mm['pair_precision'], b0_mm['pair_recall'], b0_mm['pair_f1'], b0_mm['aspect_f1'], b0_mm['sentiment_acc_on_matched']),
        ("B1 Direct SFT", "Text-Only", b1_t['pair_metrics']['pair_precision'], b1_t['pair_metrics']['pair_recall'], b1_t['pair_metrics']['pair_f1'], b1_t['pair_metrics']['aspect_f1'], b1_t['pair_metrics']['sentiment_acc_on_matched']),
        ("B1 Direct SFT", "Multimodal", b1_mm['pair_precision'], b1_mm['pair_recall'], b1_mm['pair_f1'], b1_mm['aspect_f1'], b1_mm['sentiment_acc_on_matched']),
    ]
    header = f"{'Model & Paradigm':<25} | {'Condition':<12} | {'Pair P':<8} | {'Pair R':<8} | {'Pair F1':<8} | {'Aspect F1':<10} | {'Matched Acc':<11}"
    print(header)
    print('-' * len(header))
    for r in rows:
        print(f"{r[0]:<25} | {r[1]:<12} | {r[2]:<8.2f} | {r[3]:<8.2f} | {r[4]:<8.2f} | {r[5]:<10.2f} | {r[6]:<11.2f}")
