import os
import sys
import time

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from run_targeted_benchmark import run_targeted_eval

print("=== GPU 1: STARTING B1 TARGET-GUIDED BENCHMARKS (TW15) ===", flush=True)

# 1. B1 Targeted Text-Only on TW15
run_targeted_eval('b1', 'text_only', 'twitter2015', 'test', '/opt/data/private/Qwen3-VL-8B-Instruct', '/opt/data/private/MABSA-LLM', '/opt/data/private/MABSA-LLM/data/processed', '/opt/data/private/MABSA-LLM/outputs', 1)

# 2. B1 Targeted Multimodal on TW15
run_targeted_eval('b1', 'multimodal', 'twitter2015', 'test', '/opt/data/private/Qwen3-VL-8B-Instruct', '/opt/data/private/MABSA-LLM', '/opt/data/private/MABSA-LLM/data/processed', '/opt/data/private/MABSA-LLM/outputs', 1)

print("=== GPU 1: ALL B1 TARGETED BENCHMARKS COMPLETE (TW15)! ===", flush=True)
