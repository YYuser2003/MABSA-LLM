"""Benchmark script for B0 (Zero-shot) and B1 (Direct SFT) Target-Guided / Given Aspect mode.

Evaluates Qwen3-VL-8B-Instruct on Twitter-2015 and Twitter-2017 Test sets
where target aspect entities are explicitly provided in the prompt (Targeted Sentiment Classification).
Supports both:
- Modality: text_only vs multimodal (with image)
Computes:
- Overall Sentiment Accuracy (%)
- 3-Class Macro-F1 (%)
- Class-wise POS / NEG / NEU Precision, Recall, F1-Score
- Standard Aspect-Locked Pair Metrics (Aspect-F1 = 100%)
"""

import os
import sys
import json
import argparse
from typing import List, Dict, Any, Tuple
import torch
from tqdm import tqdm
from transformers import AutoModelForImageTextToText, AutoProcessor
from peft import PeftModel
from qwen_vl_utils import process_vision_info

# Import parser
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from evaluator import parse_model_output

SYSTEM_INSTRUCTION_TARGETED = (
    "Task: Targeted Sentiment Classification for MABSA.\n"
    "Given a tweet and a list of specific target aspect entities mentioned in it, "
    "classify the sentiment polarity strictly into one of: ['POS', 'NEU', 'NEG'] for EACH given target aspect.\n"
    "Output strictly a JSON list of [aspect, sentiment] pairs. Example: [[\"target\", \"POS\"]].\n"
    "Do NOT output explanations or extra text.\n\n"
)


def evaluate_targeted_predictions(samples: List[Dict[str, Any]], cached_preds: Dict[str, Any]) -> Dict[str, Any]:
    """Computes exact targeted sentiment classification metrics against gold aspects."""
    y_true = []
    y_pred = []
    
    total_aspects = 0
    correct_count = 0
    
    for s in samples:
        sid = s["sample_id"]
        rec = cached_preds.get(sid, {})
        pred_pairs = rec.get("predicted_pairs", [])
        
        # Build normalized prediction mapping
        pred_map = {p[0].strip().lower(): p[1].strip().upper() for p in pred_pairs if len(p) >= 2}
        
        for gold_asp, gold_sent in s["pairs"]:
            gold_asp_clean = gold_asp.strip().lower()
            gold_sent_clean = gold_sent.strip().upper()
            total_aspects += 1
            
            # Lookup predicted sentiment for this target aspect
            pred_sent = pred_map.get(gold_asp_clean)
            if not pred_sent:
                # Fuzzy fallback if partial match
                for p_k, p_v in pred_map.items():
                    if gold_asp_clean in p_k or p_k in gold_asp_clean:
                        pred_sent = p_v
                        break
                        
            if not pred_sent or pred_sent not in ["POS", "NEG", "NEU"]:
                pred_sent = "NEU"  # default fallback if completely unpredicted
                
            y_true.append(gold_sent_clean)
            y_pred.append(pred_sent)
            if pred_sent == gold_sent_clean:
                correct_count += 1

    acc = (correct_count / total_aspects * 100.0) if total_aspects > 0 else 0.0
    
    classes = ["POS", "NEG", "NEU"]
    f1_list = []
    class_metrics = {}
    
    for cls in classes:
        tp = sum(1 for yt, yp in zip(y_true, y_pred) if yt == cls and yp == cls)
        fp = sum(1 for yt, yp in zip(y_true, y_pred) if yt != cls and yp == cls)
        fn = sum(1 for yt, yp in zip(y_true, y_pred) if yt == cls and yp != cls)
        support = sum(1 for yt in y_true if yt == cls)
        
        p = (tp / (tp + fp) * 100.0) if (tp + fp) > 0 else 0.0
        r = (tp / (tp + fn) * 100.0) if (tp + fn) > 0 else 0.0
        f1 = (2 * p * r / (p + r)) if (p + r) > 0 else 0.0
        f1_list.append(f1)
        class_metrics[cls] = {
            "precision": round(p, 2),
            "recall": round(r, 2),
            "f1-score": round(f1, 2),
            "support": support
        }
        
    macro_f1 = sum(f1_list) / len(f1_list) if f1_list else 0.0
    
    return {
        "total_samples": len(samples),
        "total_aspects": total_aspects,
        "accuracy": round(acc, 2),
        "macro_f1": round(macro_f1, 2),
        "aspect_f1": 100.0,
        "pair_f1": round(acc, 2),
        "class_metrics": class_metrics
    }


def run_targeted_eval(
    model_type: str,
    modality: str,
    dataset_name: str,
    split: str,
    model_path: str,
    project_root: str,
    data_dir: str,
    output_dir: str,
    gpu_id: int,
    limit: int = None
) -> Dict[str, Any]:
    device = f"cuda:{gpu_id}" if torch.cuda.is_available() else "cpu"
    data_file = os.path.join(data_dir, f"{dataset_name}_{split}.jsonl")
    os.makedirs(output_dir, exist_ok=True)
    out_preds_file = os.path.join(output_dir, f"{model_type}_targeted_{modality}_{dataset_name}_{split}_preds.jsonl")
    out_metrics_file = os.path.join(output_dir, f"{model_type}_targeted_{modality}_{dataset_name}_{split}_metrics.json")
    
    print(f"\n=======================================================")
    print(f"Running {model_type.upper()} TARGET-GUIDED [{modality.upper()}]: {dataset_name.upper()} ({split}) on {device}")
    print(f"Data input: {data_file}")
    print(f"Output preds: {out_preds_file}")
    print(f"=======================================================")
    
    # 1. Load data
    samples = []
    with open(data_file, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                samples.append(json.loads(line.strip()))
    if limit is not None and limit > 0:
        samples = samples[:limit]
    print(f"Loaded {len(samples)} samples.")
    
    # 2. Check existing cache
    cached_preds = {}
    if os.path.exists(out_preds_file):
        with open(out_preds_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    item = json.loads(line.strip())
                    cached_preds[item["sample_id"]] = item
        print(f"Found {len(cached_preds)} already evaluated samples in cache.")
        
    if len(cached_preds) < len(samples):
        print(f"Loading base processor and model from {model_path}...")
        processor = AutoProcessor.from_pretrained(model_path, local_files_only=True)
        model = AutoModelForImageTextToText.from_pretrained(
            model_path,
            torch_dtype=torch.bfloat16,
            device_map=device,
            local_files_only=True
        )
        
        if model_type == "b1":
            ckpt_path = os.path.join(output_dir, f"b1_direct_sft_{dataset_name}/checkpoint_epoch_3")
            print(f"Loading LoRA adapter for B1 from {ckpt_path}...")
            model = PeftModel.from_pretrained(model, ckpt_path)
            
        model.eval()
        
        with open(out_preds_file, 'a', encoding='utf-8') as f_out:
            for sample in tqdm(samples, desc=f"{model_type.upper()}-Targeted-{modality}-{dataset_name}"):
                sample_id = sample["sample_id"]
                if sample_id in cached_preds:
                    continue
                    
                tweet_text = sample["text"]
                target_aspects = [p[0] for p in sample.get("pairs", [])]
                
                prompt = (
                    f"{SYSTEM_INSTRUCTION_TARGETED}"
                    f"Tweet: {tweet_text}\n"
                    f"Target Aspects: {json.dumps(target_aspects, ensure_ascii=False)}\n"
                    f"Output:"
                )
                
                if modality == "multimodal":
                    img_abs = os.path.join(project_root, sample["image"])
                    messages = [
                        {
                            "role": "user",
                            "content": [
                                {"type": "image", "image": f"file://{img_abs}"},
                                {"type": "text", "text": prompt}
                            ]
                        }
                    ]
                    try:
                        text_input = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
                        image_inputs, video_inputs = process_vision_info(messages)
                        inputs = processor(
                            text=[text_input],
                            images=image_inputs,
                            videos=video_inputs,
                            padding=True,
                            return_tensors="pt"
                        ).to(device)
                    except Exception as e:
                        print(f"\n[Warning] Multimodal processor error on {sample_id}: {e}")
                        inputs = None
                else:
                    # Text-only
                    messages = [
                        {
                            "role": "user",
                            "content": [
                                {"type": "text", "text": prompt}
                            ]
                        }
                    ]
                    try:
                        text_input = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
                        inputs = processor(
                            text=[text_input],
                            padding=True,
                            return_tensors="pt"
                        ).to(device)
                    except Exception as e:
                        print(f"\n[Warning] Text-only processor error on {sample_id}: {e}")
                        inputs = None
                        
                raw_pred = "[]"
                if inputs is not None:
                    try:
                        with torch.inference_mode():
                            output_ids = model.generate(
                                **inputs,
                                max_new_tokens=64,
                                do_sample=False
                            )
                        generated = output_ids[:, inputs.input_ids.shape[1]:]
                        raw_pred = processor.batch_decode(generated, skip_special_tokens=True)[0].strip()
                    except Exception as e:
                        print(f"\n[Warning] Generation error on {sample_id}: {e}")
                        raw_pred = "[]"
                        
                parsed_pairs = parse_model_output(raw_pred)
                record = {
                    "sample_id": sample_id,
                    "text": tweet_text,
                    "target_aspects": target_aspects,
                    "condition": f"targeted_{modality}",
                    "ground_truth_pairs": sample["pairs"],
                    "raw_output": raw_pred,
                    "predicted_pairs": parsed_pairs
                }
                f_out.write(json.dumps(record, ensure_ascii=False) + '\n')
                f_out.flush()
                cached_preds[sample_id] = record

    # 3. Compute Metrics
    metrics = evaluate_targeted_predictions(samples, cached_preds)
    combined_metrics = {
        "model_type": model_type,
        "modality": modality,
        "setting": "targeted_given_aspects",
        "dataset": dataset_name,
        "split": split,
        **metrics
    }
    
    print(f"\n===== RESULTS for {model_type.upper()} TARGETED [{modality.upper()}]: {dataset_name.upper()} {split} =====")
    print(f"Accuracy : {combined_metrics['accuracy']}%")
    print(f"Macro-F1 : {combined_metrics['macro_f1']}%")
    print(f"POS F1   : {combined_metrics['class_metrics']['POS']['f1-score']}%")
    print(f"NEG F1   : {combined_metrics['class_metrics']['NEG']['f1-score']}%")
    print(f"NEU F1   : {combined_metrics['class_metrics']['NEU']['f1-score']}%")
    
    with open(out_metrics_file, 'w', encoding='utf-8') as f:
        json.dump(combined_metrics, f, indent=2, ensure_ascii=False)
    print(f"Metrics saved to {out_metrics_file}\n")
    return combined_metrics


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_type", type=str, required=True, choices=["b0", "b1"])
    parser.add_argument("--modality", type=str, required=True, choices=["text_only", "multimodal"])
    parser.add_argument("--dataset", type=str, required=True, choices=["twitter2015", "twitter2017"])
    parser.add_argument("--split", type=str, default="test")
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--model_path", type=str, default="/opt/data/private/Qwen3-VL-8B-Instruct")
    parser.add_argument("--project_root", type=str, default="/opt/data/private/MABSA-LLM")
    parser.add_argument("--data_dir", type=str, default="/opt/data/private/MABSA-LLM/data/processed")
    parser.add_argument("--output_dir", type=str, default="/opt/data/private/MABSA-LLM/outputs")
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()
    
    run_targeted_eval(
        model_type=args.model_type,
        modality=args.modality,
        dataset_name=args.dataset,
        split=args.split,
        model_path=args.model_path,
        project_root=args.project_root,
        data_dir=args.data_dir,
        output_dir=args.output_dir,
        gpu_id=args.gpu_id,
        limit=args.limit
    )
