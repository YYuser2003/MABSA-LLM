import json
import os
from collections import defaultdict
from typing import List, Tuple, Dict, Any

from evaluator import compute_pair_metrics

def diagnose_dataset(preds_path: str, dataset_label: str):
    print(f"\n=======================================================")
    print(f"DIAGNOSTIC ANALYSIS: {dataset_label}")
    print(f"File: {preds_path}")
    print(f"=======================================================")
    
    samples = []
    with open(preds_path, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                samples.append(json.loads(line.strip()))
                
    # Group samples by gold aspect count
    bins = {
        "1": [],
        "2": [],
        "3": [],
        ">=4": []
    }
    
    for s in samples:
        n_gold = len(s["ground_truth_pairs"])
        if n_gold == 1:
            bins["1"].append(s)
        elif n_gold == 2:
            bins["2"].append(s)
        elif n_gold == 3:
            bins["3"].append(s)
        else:
            bins[">=4"].append(s)
            
    print(f"{'# Gold Aspects':<15} | {'Samples':<8} | {'Aspect P':<10} | {'Aspect R':<10} | {'Aspect F1':<10} | {'Pair P':<8} | {'Pair R':<8} | {'Pair F1':<8} | {'Sent Acc':<8}")
    print("-" * 105)
    
    table_rows = []
    for bin_name, bin_samples in bins.items():
        if not bin_samples:
            continue
        preds = [s["predicted_pairs"] for s in bin_samples]
        gts = [s["ground_truth_pairs"] for s in bin_samples]
        m = compute_pair_metrics(preds, gts)
        
        row = {
            "bin": bin_name,
            "count": len(bin_samples),
            "aspect_p": m["aspect_precision"],
            "aspect_r": m["aspect_recall"],
            "aspect_f1": m["aspect_f1"],
            "pair_p": m["pair_precision"],
            "pair_r": m["pair_recall"],
            "pair_f1": m["pair_f1"],
            "sent_acc": m["sentiment_acc_on_matched"]
        }
        table_rows.append(row)
        print(f"{bin_name:<15} | {len(bin_samples):<8} | {m['aspect_precision']:<10.2f} | {m['aspect_recall']:<10.2f} | {m['aspect_f1']:<10.2f} | {m['pair_precision']:<8.2f} | {m['pair_recall']:<8.2f} | {m['pair_f1']:<8.2f} | {m['sentiment_acc_on_matched']:<8.2f}")
    print("=" * 105)
    return table_rows

if __name__ == '__main__':
    base_dir = "d:/YY/MABSA-LLM/outputs"
    tw15_file = os.path.join(base_dir, "b0_zeroshot_twitter2015_test_preds.jsonl")
    tw17_file = os.path.join(base_dir, "b0_zeroshot_twitter2017_test_preds.jsonl")
    
    diagnose_dataset(tw15_file, "Twitter-2015 Test (B0 Zero-shot)")
    diagnose_dataset(tw17_file, "Twitter-2017 Test (B0 Zero-shot)")
