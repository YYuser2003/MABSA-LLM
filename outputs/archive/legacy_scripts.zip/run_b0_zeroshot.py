import os
import json
import argparse
from tqdm import tqdm
from typing import List, Dict, Any

from evaluator import parse_model_output, compute_pair_metrics

SYSTEM_PROMPT = """You are an expert in Multimodal Aspect-Based Sentiment Analysis (MABSA).
Your task is to identify all aspect targets (specific entities, names, or opinion targets) explicitly mentioned in the tweet and predict the sentiment polarity towards each aspect.
The sentiment polarity must be strictly one of: ["POS", "NEU", "NEG"].
Do NOT output reasoning, explanations, or any extra text.
Output strictly a JSON list of [aspect, sentiment] pairs.
Example: [["iPhone", "POS"], ["battery", "NEG"]]
If there are no aspect targets in the tweet, output []."""

def format_prompt(tweet_text: str) -> str:
    return f"Tweet: {tweet_text}\nOutput JSON list of [aspect, sentiment]:"

def load_dataset(jsonl_path: str) -> List[Dict[str, Any]]:
    samples = []
    with open(jsonl_path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                samples.append(json.loads(line))
    return samples

def evaluate_predictions(samples: List[Dict[str, Any]], predictions: List[str]) -> Dict[str, float]:
    parsed_preds = [parse_model_output(p) for p in predictions]
    ground_truths = [s["pairs"] for s in samples]
    metrics = compute_pair_metrics(parsed_preds, ground_truths)
    return metrics

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run B0 Zero-shot Qwen3-VL-8B on MABSA")
    parser.add_argument("--dataset", type=str, default="twitter2015", choices=["twitter2015", "twitter2017"])
    parser.add_argument("--split", type=str, default="test", choices=["test", "dev"])
    parser.add_argument("--data_dir", type=str, default="data/processed")
    parser.add_argument("--output_file", type=str, default=None)
    args = parser.parse_args()

    input_file = os.path.join(args.data_dir, f"{args.dataset}_{args.split}.jsonl")
    samples = load_dataset(input_file)
    print(f"Loaded {len(samples)} samples from {input_file}")
