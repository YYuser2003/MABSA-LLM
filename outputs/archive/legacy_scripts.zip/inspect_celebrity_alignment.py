import json

files = [
    ('Twitter-2015', 'outputs/g3_benchmark/g3_max2_twitter2015_test.jsonl'),
    ('Twitter-2017', 'outputs/g3_benchmark/g3_max2_twitter2017_test.jsonl')
]

for ds_name, file_path in files:
    total_samples = 0
    multi_aspect_samples = 0
    name_in_vision_desc = 0
    multi_person_aligned = 0
    samples_found = []
    
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip():
                continue
            total_samples += 1
            d = json.loads(line)
            pairs = d.get('final_pairs', [])
            if len(pairs) > 1:
                multi_aspect_samples += 1
                
            img_desc = d.get('image_initial', {}).get('description', '')
            rounds = d.get('rounds', [])
            
            # Check if aspect names appear in image description
            matched_aspects = []
            for asp, sent in pairs:
                asp_clean = asp.lower().strip()
                if len(asp_clean) >= 3 and asp_clean in img_desc.lower():
                    matched_aspects.append(asp)
                    
            if matched_aspects:
                name_in_vision_desc += 1
                if len(pairs) > 1 and len(matched_aspects) >= 1:
                    multi_person_aligned += 1
                    samples_found.append({
                        'sid': d['sample_id'],
                        'text': d['text'],
                        'pairs': pairs,
                        'matched': matched_aspects,
                        'img_desc': img_desc,
                        'rounds': [(r.get('query_type'), r.get('question'), r.get('visual_evidence', '')) for r in rounds]
                    })

    print(f"=== {ds_name} ===")
    print(f"Total Samples: {total_samples}")
    print(f"Multi-Aspect Samples: {multi_aspect_samples} ({multi_aspect_samples/total_samples*100:.1f}%)")
    print(f"Samples with Aspect Name explicitly identified by Vision: {name_in_vision_desc} ({name_in_vision_desc/total_samples*100:.1f}%)")
    print(f"Multi-Aspect Samples with Visual Alignment: {multi_person_aligned}")
    print("\n--- Representative Multi-Aspect / Multi-Person Examples ---")
    for ex in samples_found[:3]:
        print(f"[{ex['sid']}]")
        print(f"  Tweet: {ex['text']}")
        print(f"  Target Aspects: {ex['pairs']}")
        print(f"  Image Description: {ex['img_desc'][:300]}...")
        if ex['rounds']:
            print(f"  Active Probes: {ex['rounds']}")
        print("-" * 60)
