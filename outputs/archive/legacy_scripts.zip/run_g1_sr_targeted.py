"""Targeted G1-SR (Direct Multimodal + Self-Refinement) Compute-Matched Baseline.

Matches G3's test-time compute budget (3 LLM turns) WITHOUT the Active Questioning Controller.
Given (Tweet, Image, Target Aspects):
Turn 1: Initial Direct Multimodal Prediction (reuses cached G1 if available, or generates fresh)
Turn 2: Critical Multimodal Self-Audit
Turn 3: Final Decision Synthesis
"""

import os
import sys
import json
import time
import argparse
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, Any, List, Optional

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

try:
    from bacr.gemini_client import GeminiClient
except ImportError:
    from active_visual_reasoning.gemini_client import GeminiClient

G1_CRITIQUE_PROMPT = """You are a rigorous Multimodal Sentiment Critic and Auditor for Aspect-Based Sentiment Analysis.
You are inspecting an initial multimodal sentiment prediction for a tweet, an image, and specific target aspects.

Critique Guidelines:
1. Check if an aspect's sentiment was misled by background visual noise or unrelated people smiling/frowning.
2. Check if subtle facial expressions, postures, or OCR text directly tied to the target aspect were missed.
3. Check for irony, sarcasm, or text-visual contradictions.
4. For EACH target aspect, decide whether the initial sentiment is 'CONFIRMED' or 'NEEDS_REVISION'.

Output strictly as a valid JSON object:
{
  "critique_units": [
    {
      "aspect": "<exact aspect text>",
      "initial_sentiment": "POS|NEG|NEU",
      "verdict": "CONFIRMED|NEEDS_REVISION",
      "recommended_sentiment": "POS|NEG|NEU",
      "critique_rationale": "<1-sentence evidence-based critique>"
    }
  ]
}"""

G1_REFINED_FINAL_PROMPT = """You are an expert multimodal aspect-based sentiment analysis assistant performing Final Decision Synthesis.
You are given:
1. The tweet and paired image;
2. Target aspects and their initial sentiment assignments;
3. Your own critical self-audit.

Synthesize all visual and textual evidence and output the FINAL, definitive sentiment for EACH target aspect strictly as one of: POS, NEG, NEU.

Output strictly as a valid JSON object:
{
  "predictions": [
    {
      "aspect": "<exact aspect text>",
      "sentiment": "POS|NEG|NEU",
      "synthesis_rationale": "<brief final justification>"
    }
  ],
  "pairs": [
    ["<exact aspect text>", "POS|NEG|NEU"]
  ]
}"""


def load_g1_cache(g1_file: str) -> Dict[str, Dict[str, Any]]:
    cache = {}
    if os.path.exists(g1_file):
        with open(g1_file, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    d = json.loads(line)
                    cache[d["sample_id"]] = d
    return cache


def run_single_g1_sr(
    client: GeminiClient,
    sample: Dict[str, Any],
    initial_g1_item: Optional[Dict[str, Any]],
    image_base_dir: str
) -> Dict[str, Any]:
    sample_id = sample.get("sample_id", "unknown")
    text = sample.get("text", "")
    rel_img = sample.get("image", "")
    full_img = os.path.join(image_base_dir, rel_img)
    target_aspects = [p[0] for p in sample.get("pairs", [])]

    # Turn 1: Initial Multimodal
    if initial_g1_item and "predictions" in initial_g1_item:
        initial_predictions = initial_g1_item["predictions"]
        initial_pairs = [[p["aspect"], p["sentiment"]] for p in initial_predictions]
    else:
        # Fallback fresh Turn 1
        t1_user = f"Tweet: {text}\nTarget Aspects: {json.dumps(target_aspects, ensure_ascii=False)}\nOutput JSON with predictions for each aspect."
        t1_res, _, _ = client.call_vision(
            system_prompt="Classify sentiment for each target aspect as POS, NEG, or NEU based on tweet and image. Output JSON with key 'predictions': [{'aspect': ..., 'sentiment': ...}]",
            user_text=t1_user,
            image_path=full_img
        )
        initial_predictions = t1_res.get("predictions", [])
        initial_pairs = [[p["aspect"], p["sentiment"]] for p in initial_predictions]

    # Turn 2: Self-Critique
    t2_user = f"""Tweet: "{text}"
Target Aspects and Initial Predictions:
{json.dumps(initial_predictions, ensure_ascii=False, indent=2)}

Examine the image carefully and critique whether any sentiment assignment is flawed or misled by visual noise."""
    t2_res, _, _ = client.call_vision(
        system_prompt=G1_CRITIQUE_PROMPT,
        user_text=t2_user,
        image_path=full_img
    )
    critique_units = t2_res.get("critique_units", [])

    # Turn 3: Final Synthesis
    t3_user = f"""Tweet: "{text}"
Initial Predictions:
{json.dumps(initial_predictions, ensure_ascii=False, indent=2)}

Self-Critique Assessment:
{json.dumps(critique_units, ensure_ascii=False, indent=2)}

Synthesize all points and output the definitive final aspect-sentiment pairs."""
    t3_res, _, _ = client.call_vision(
        system_prompt=G1_REFINED_FINAL_PROMPT,
        user_text=t3_user,
        image_path=full_img
    )
    final_pairs = t3_res.get("pairs", [])
    if not final_pairs and "predictions" in t3_res:
        final_pairs = [[p["aspect"], p["sentiment"]] for p in t3_res["predictions"]]
    if not final_pairs:
        final_pairs = initial_pairs

    return {
        "sample_id": sample_id,
        "method": "G1-SR",
        "text": text,
        "target_aspects": target_aspects,
        "initial_pairs": initial_pairs,
        "critique_units": critique_units,
        "final_pairs": final_pairs
    }


def evaluate_g1_sr(samples: List[Dict[str, Any]], records: List[Dict[str, Any]]) -> Dict[str, Any]:
    rec_map = {r["sample_id"]: r for r in records}
    y_true = []
    y_pred = []
    y_init = []

    for s in samples:
        sid = s["sample_id"]
        rec = rec_map.get(sid, {})
        final_map = {p[0].lower().strip(): p[1].upper().strip() for p in rec.get("final_pairs", [])}
        init_map = {p[0].lower().strip(): p[1].upper().strip() for p in rec.get("initial_pairs", [])}

        for gold_asp, gold_s in s["pairs"]:
            asp_clean = gold_asp.lower().strip()
            gold_s_clean = gold_s.upper().strip()
            y_true.append(gold_s_clean)
            y_pred.append(final_map.get(asp_clean, "NEU"))
            y_init.append(init_map.get(asp_clean, "NEU"))

    def calc_metrics(yt, yp):
        acc = sum(1 for a, b in zip(yt, yp) if a == b) / len(yt) * 100.0
        classes = ["POS", "NEG", "NEU"]
        f1s = []
        c_dict = {}
        for c in classes:
            tp = sum(1 for a, b in zip(yt, yp) if a == c and b == c)
            fp = sum(1 for a, b in zip(yt, yp) if a != c and b == c)
            fn = sum(1 for a, b in zip(yt, yp) if a == c and b != c)
            p = tp / (tp + fp) * 100.0 if tp + fp > 0 else 0.0
            r = tp / (tp + fn) * 100.0 if tp + fn > 0 else 0.0
            f = 2 * p * r / (p + r) if p + r > 0 else 0.0
            f1s.append(f)
            c_dict[c] = {"precision": round(p, 2), "recall": round(r, 2), "f1-score": round(f, 2)}
        return round(acc, 2), round(sum(f1s)/len(f1s), 2), c_dict

    final_acc, final_mf1, final_cls = calc_metrics(y_true, y_pred)
    init_acc, init_mf1, init_cls = calc_metrics(y_true, y_init)

    return {
        "final_accuracy": final_acc,
        "final_macro_f1": final_mf1,
        "initial_accuracy": init_acc,
        "initial_macro_f1": init_mf1,
        "delta_accuracy": round(final_acc - init_acc, 2),
        "delta_macro_f1": round(final_mf1 - init_mf1, 2),
        "class_metrics_final": final_cls
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=["twitter2015", "twitter2017"], default="twitter2015")
    parser.add_argument("--split", default="test")
    parser.add_argument("--concurrency", type=int, default=6)
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()

    gold_path = f"data/processed/{args.dataset}_{args.split}.jsonl"
    out_dir = "outputs/baselines"
    os.makedirs(out_dir, exist_ok=True)
    out_preds = os.path.join(out_dir, f"g1_sr_{args.dataset}_{args.split}.jsonl")
    out_metrics = os.path.join(out_dir, f"metrics_g1_sr_{args.dataset}_{args.split}.json")

    # Load G1 cached items
    g1_cache_file = f"outputs/gemini_benchmark/gemini38_multimodal_{args.dataset}_{args.split}.jsonl"
    g1_cache = load_g1_cache(g1_cache_file)
    print(f"Loaded {len(g1_cache)} initial G1 predictions from cache.")

    samples = []
    with open(gold_path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                samples.append(json.loads(line))
                if args.limit and len(samples) >= args.limit:
                    break

    existing_ids = set()
    completed_records = []
    if os.path.exists(out_preds):
        with open(out_preds, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    rec = json.loads(line)
                    existing_ids.add(rec["sample_id"])
                    completed_records.append(rec)

    pending = [s for s in samples if s["sample_id"] not in existing_ids]
    print(f"[{args.dataset.upper()}] Total: {len(samples)}, Completed: {len(existing_ids)}, Pending: {len(pending)}")

    if pending:
        client = GeminiClient(allow_fallback=False)
        lock = threading.Lock()
        done_cnt = len(existing_ids)

        def worker(sample):
            nonlocal done_cnt
            sid = sample["sample_id"]
            init_item = g1_cache.get(sid)
            try:
                res = run_single_g1_sr(client, sample, init_item, PROJECT_ROOT)
                with lock:
                    with open(out_preds, "a", encoding="utf-8") as f_out:
                        f_out.write(json.dumps(res, ensure_ascii=False) + "\n")
                        f_out.flush()
                    completed_records.append(res)
                    done_cnt += 1
                    print(f"[{done_cnt}/{len(samples)}] Success: {sid}")
                return True
            except Exception as e:
                print(f"[ERROR] {sid}: {e}")
                return False

        with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
            futures = {executor.submit(worker, s): s for s in pending}
            for f in as_completed(futures):
                f.result()

    metrics = evaluate_g1_sr(samples, completed_records)
    print("\n===== G1-SR FINAL RESULTS =====")
    print(json.dumps(metrics, indent=2))
    with open(out_metrics, "w", encoding="utf-8") as f_m:
        json.dump(metrics, f_m, indent=2)
    print(f"Saved metrics to: {out_metrics}")


if __name__ == "__main__":
    main()
