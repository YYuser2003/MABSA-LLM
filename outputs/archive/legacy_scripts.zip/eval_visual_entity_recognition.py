"""
Full-scale Visual Entity & Celebrity Recognition Evaluation for Qwen3-VL-8B across Twitter-2015 & Twitter-2017.

Evaluates:
1. Physical Visibility: Is the target aspect physically visible in the image?
2. Entity Classification: person / organization / location / object / other.
3. Celebrity Identification: When the aspect is a person, can Qwen3-VL-8B identify their real-world famous identity?
4. Aspect-Image Grounding: Produces quantitative grounding and recognition metrics across TW15 and TW17.
"""

import os
import sys
import json
import argparse
import re
from typing import List, Dict, Any
from tqdm import tqdm

import torch
from transformers import AutoModelForImageTextToText, AutoProcessor
from qwen_vl_utils import process_vision_info

PROMPT_TEMPLATE = """You are an expert visual entity recognition and celebrity identification assistant.
Target Aspects mentioned in the tweet: {aspects_json}

Analyze the provided image carefully and determine:
1. Is EACH target aspect physically visible or depicted in the image? (true or false)
2. What is the entity type of the aspect? Must be one of: ["person", "organization", "location", "object", "other"]
3. If it is a person, what is the recognized celebrity/public figure full name (or "Unknown" if an ordinary person or unrecognizable)?
4. Brief visual evidence describing what visual features confirm this (or "none").

Output strictly a valid JSON array of objects conforming to this schema:
[
  {{
    "aspect": "...",
    "is_visible": true,
    "category": "person",
    "recognized_name": "...",
    "visual_evidence": "..."
  }}
]
Do not output markdown code fences or any other text."""

def parse_json_response(raw_text: str) -> List[Dict[str, Any]]:
    clean = raw_text.strip()
    if clean.startswith("```json"):
        clean = clean[7:]
    elif clean.startswith("```"):
        clean = clean[3:]
    if clean.endswith("```"):
        clean = clean[:-3]
    clean = clean.strip()
    
    try:
        data = json.loads(clean)
        if isinstance(data, list):
            return data
        elif isinstance(data, dict):
            return [data]
    except Exception:
        # Fallback regex extraction of JSON array
        m = re.search(r'\[.*\]', clean, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                pass
    return []

def run_evaluation(
    dataset_name: str,
    split: str,
    model_path: str,
    data_dir: str,
    output_dir: str,
    device_id: int = 0,
    limit: int = None
):
    data_file = os.path.join(data_dir, f"{dataset_name}_{split}.jsonl")
    os.makedirs(output_dir, exist_ok=True)
    out_preds_file = os.path.join(output_dir, f"entity_recognition_{dataset_name}_{split}_preds.jsonl")
    
    print(f"\n=======================================================")
    print(f"Running Visual Entity Recognition: Qwen3-VL-8B on {dataset_name.upper()} ({split}) on GPU {device_id}")
    print(f"Data input: {data_file}")
    print(f"Output preds: {out_preds_file}")
    print(f"=======================================================")
    
    samples = []
    with open(data_file, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                samples.append(json.loads(line.strip()))
    if limit is not None and limit > 0:
        samples = samples[:limit]
    print(f"Loaded {len(samples)} samples.")
    
    cached_preds = {}
    if os.path.exists(out_preds_file):
        with open(out_preds_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    item = json.loads(line.strip())
                    cached_preds[item["sample_id"]] = item
        print(f"Found {len(cached_preds)} already processed samples in cache. Resuming...")
        
    remaining_samples = [s for s in samples if s["sample_id"] not in cached_preds]
    
    if remaining_samples:
        print(f"Loading Qwen3-VL-8B on cuda:{device_id}...")
        device = f"cuda:{device_id}"
        processor = AutoProcessor.from_pretrained(model_path, local_files_only=True)
        model = AutoModelForImageTextToText.from_pretrained(
            model_path,
            torch_dtype=torch.bfloat16,
            device_map=device,
            local_files_only=True
        )
        print("Model loaded successfully.")
        
        base_dir = "/opt/data/private/MABSA-LLM"
        
        with open(out_preds_file, 'a', encoding='utf-8') as f_out:
            for sample in tqdm(remaining_samples, desc=f"Visual Probing {dataset_name}_{split} (GPU {device_id})"):
                sample_id = sample["sample_id"]
                aspects = sample.get("aspects", [p[0] for p in sample.get("pairs", [])])
                img_rel = sample["image"]
                img_abs = os.path.join(base_dir, img_rel)
                
                aspects_str = json.dumps(aspects, ensure_ascii=False)
                user_text = PROMPT_TEMPLATE.format(aspects_json=aspects_str)
                
                messages = [
                    {
                        "role": "user",
                        "content": [
                            {"type": "image", "image": f"file://{img_abs}"},
                            {"type": "text", "text": user_text}
                        ]
                    }
                ]
                
                try:
                    text_input = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
                    image_inputs, video_inputs = process_vision_info(messages)
                    
                    inputs = processor(
                        text=[text_input],
                        images=image_inputs,
                        videos=video_inputs,
                        padding=True,
                        return_tensors="pt"
                    ).to(device)
                    
                    with torch.inference_mode():
                        output_ids = model.generate(
                            **inputs,
                            max_new_tokens=256,
                            do_sample=False
                        )
                    
                    generated = output_ids[:, inputs.input_ids.shape[1]:]
                    raw_pred = processor.batch_decode(generated, skip_special_tokens=True)[0].strip()
                except Exception as e:
                    raw_pred = "[]"
                    print(f"\n[Warning] Error on {sample_id}: {e}")
                    
                parsed_records = parse_json_response(raw_pred)
                
                record = {
                    "sample_id": sample_id,
                    "dataset": dataset_name,
                    "split": split,
                    "image": img_rel,
                    "text": sample.get("text", ""),
                    "aspects": aspects,
                    "gold_pairs": sample.get("pairs", []),
                    "raw_output": raw_pred,
                    "visual_entity_predictions": parsed_records
                }
                
                f_out.write(json.dumps(record, ensure_ascii=False) + '\n')
                f_out.flush()
                cached_preds[sample_id] = record
                
    print(f"Completed {len(cached_preds)} / {len(samples)} samples for {dataset_name}_{split}.\n")
    return out_preds_file

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=str, required=True, choices=["twitter2015", "twitter2017"])
    parser.add_argument("--split", type=str, required=True, choices=["dev", "test"])
    parser.add_argument("--device_id", type=int, default=0)
    parser.add_argument("--model_path", type=str, default="/opt/data/private/Qwen3-VL-8B-Instruct")
    parser.add_argument("--data_dir", type=str, default="/opt/data/private/MABSA-LLM/data/processed")
    parser.add_argument("--output_dir", type=str, default="/opt/data/private/MABSA-LLM/outputs/visual_probing")
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()
    
    run_evaluation(
        dataset_name=args.dataset,
        split=args.split,
        model_path=args.model_path,
        data_dir=args.data_dir,
        output_dir=args.output_dir,
        device_id=args.device_id,
        limit=args.limit
    )
