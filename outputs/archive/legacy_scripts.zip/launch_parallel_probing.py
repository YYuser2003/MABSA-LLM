"""
Master Multi-GPU Parallel Launcher for Visual Entity & Celebrity Recognition.
Dynamically schedules 4 tasks across 3 GPUs (GPU 0, 1, 2):
  Task 1: (twitter2015, dev)
  Task 2: (twitter2015, test)
  Task 3: (twitter2017, dev)
  Task 4: (twitter2017, test)
"""

import os
import sys
import subprocess
import time
from queue import Queue
from threading import Thread

PYTHON_BIN = "/opt/conda/envs/qwen3vl/bin/python"
SCRIPTS_DIR = "/opt/data/private/MABSA-LLM/scripts"

TASKS = [
    ("twitter2015", "dev"),
    ("twitter2015", "test"),
    ("twitter2017", "dev"),
    ("twitter2017", "test")
]

GPUS = [0, 1, 2]

def worker(gpu_id: int, task_queue: Queue, results: list):
    while not task_queue.empty():
        try:
            ds, sp = task_queue.get_nowait()
        except Exception:
            break
            
        print(f"[GPU {gpu_id}] Starting task: {ds} ({sp})...", flush=True)
        t_start = time.time()
        
        cmd = [
            PYTHON_BIN,
            f"{SCRIPTS_DIR}/eval_visual_entity_recognition.py",
            "--dataset", ds,
            "--split", sp,
            "--device_id", str(gpu_id)
        ]
        
        proc = subprocess.run(cmd, capture_output=True, text=True)
        elapsed = time.time() - t_start
        
        if proc.returncode == 0:
            print(f"[GPU {gpu_id}] COMPLETED task: {ds} ({sp}) in {elapsed:.1f}s!", flush=True)
            results.append((ds, sp, True, elapsed))
        else:
            print(f"[GPU {gpu_id}] ERROR on task: {ds} ({sp}):\n{proc.stderr[-500:]}", flush=True)
            results.append((ds, sp, False, elapsed))
            
        task_queue.task_done()

def main():
    print("=================================================================")
    print("Launching Dynamic 3-GPU Probing across TW15 & TW17...")
    print(f"Tasks: {TASKS}")
    print(f"Available GPUs: {GPUS}")
    print("=================================================================\n", flush=True)
    
    t0 = time.time()
    
    q = Queue()
    for task in TASKS:
        q.put(task)
        
    results = []
    threads = []
    
    for gpu_id in GPUS:
        t = Thread(target=worker, args=(gpu_id, q, results))
        t.start()
        threads.append(t)
        
    for t in threads:
        t.join()
        
    total_elapsed = time.time() - t0
    print(f"\nAll tasks finished in {total_elapsed:.1f}s (~{total_elapsed/60:.2f} minutes).", flush=True)
    
    # Run analysis
    print("\nAggregating and computing final metrics...", flush=True)
    cmd_analysis = f"{PYTHON_BIN} {SCRIPTS_DIR}/analyze_visual_probing.py"
    subprocess.run(cmd_analysis, shell=True)

if __name__ == '__main__':
    main()
