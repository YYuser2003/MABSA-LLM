import json
import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from evaluator import compute_pair_metrics

for ds in ['twitter2015', 'twitter2017']:
    fn = f'D:/YY/MABSA-LLM/outputs/b1_direct_sft_{ds}_dev_preds.jsonl'
    with open(fn, 'r', encoding='utf-8') as f:
        samples = [json.loads(l) for l in f if l.strip()]
        
    preds = [s["predicted_pairs"] for s in samples]
    gts = [s["ground_truth_pairs"] for s in samples]
    
    metrics = compute_pair_metrics(preds, gts)
    print(f"=== {ds.upper()} DEV METRICS ===")
    print(f"Pair P/R/F1:   {metrics['pair_precision']:.2f} / {metrics['pair_recall']:.2f} / {metrics['pair_f1']:.2f}")
    print(f"Aspect P/R/F1: {metrics['aspect_precision']:.2f} / {metrics['aspect_recall']:.2f} / {metrics['aspect_f1']:.2f}")
    print(f"Cond Sent Acc: {metrics['sentiment_acc_on_matched']:.2f}%\n")
