import os
import sys
import time
import subprocess
from threading import Thread

PYTHON_BIN = '/opt/conda/envs/qwen3vl/bin/python'
BASE_DIR = '/opt/data/private/MABSA-LLM'

def watch_and_run(preds_file, target_count, script_name, gpu_id):
    print(f"[Watcher GPU {gpu_id}] Waiting for {preds_file} to reach {target_count} lines...", flush=True)
    while True:
        if os.path.exists(preds_file):
            with open(preds_file, 'r', encoding='utf-8') as f:
                lines = sum(1 for line in f if line.strip())
            if lines >= target_count:
                print(f"[Watcher GPU {gpu_id}] {preds_file} reached {lines}/{target_count}! Launching {script_name}...", flush=True)
                break
        time.sleep(5)
        
    time.sleep(2)  # brief pause for clean memory release
    cmd = [PYTHON_BIN, os.path.join(BASE_DIR, 'scripts', script_name)]
    subprocess.run(cmd)
    print(f"[Watcher GPU {gpu_id}] {script_name} FINISHED!", flush=True)

if __name__ == '__main__':
    t1 = Thread(target=watch_and_run, args=(
        os.path.join(BASE_DIR, 'outputs/b1_textonly_twitter2015_test_preds.jsonl'),
        674,
        'run_b1_targeted_gpu1.py',
        1
    ))
    t2 = Thread(target=watch_and_run, args=(
        os.path.join(BASE_DIR, 'outputs/b1_textonly_twitter2017_test_preds.jsonl'),
        587,
        'run_b1_targeted_gpu2.py',
        2
    ))
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    print("All B1 targeted tasks complete!", flush=True)
