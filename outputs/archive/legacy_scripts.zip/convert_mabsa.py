import os
import json
from collections import OrderedDict

LABEL_MAP_TSV = {
    '0': 'NEG',
    '1': 'NEU',
    '2': 'POS'
}

def process_split(dataset_name, split, base_dir, output_dir):
    tsv_path = os.path.join(base_dir, dataset_name, f"{split}.tsv")
    img_dir_rel = f"{dataset_name}_images"
    img_dir_abs = os.path.join(base_dir, img_dir_rel)
    
    with open(tsv_path, 'r', encoding='utf-8', errors='ignore') as f:
        lines = [l.strip().split('\t') for l in f.readlines() if l.strip()]
    
    data_rows = lines[1:]  # skip header
    
    # Group by (image_id, reconstructed_tweet)
    # Using OrderedDict to preserve the original sequence of samples
    samples = OrderedDict()
    
    for row in data_rows:
        row_id = row[0]
        raw_label = row[1]
        img_id = row[2]
        masked_text = row[3]
        aspect_term = row[4]
        
        # 1. Exact text reconstruction & span extraction
        t_pos = masked_text.find('$T$')
        if t_pos == -1:
            # Fallback if $T$ is missing
            full_text = masked_text
            start_char = full_text.find(aspect_term)
            end_char = start_char + len(aspect_term) if start_char != -1 else -1
        else:
            prefix = masked_text[:t_pos]
            suffix = masked_text[t_pos + 3:]
            full_text = prefix + aspect_term + suffix
            start_char = t_pos
            end_char = t_pos + len(aspect_term)
        
        norm_text = ' '.join(full_text.split())
        sentiment = LABEL_MAP_TSV.get(raw_label, raw_label)
        
        key = (img_id, norm_text)
        
        if key not in samples:
            samples[key] = {
                "sample_id": f"{dataset_name}_{split}_{len(samples):04d}",
                "dataset": dataset_name,
                "split": split,
                "image": f"IJCAI2019_data/{img_dir_rel}/{img_id}",
                "image_id": img_id,
                "text": norm_text,
                "aspects": [],
                "sentiments": [],
                "pairs": [],
                "annotations": [],
                "reasoning_units": []  # Empty placeholder for Teacher CoT fields
            }
            
        sample = samples[key]
        sample["aspects"].append(aspect_term)
        sample["sentiments"].append(sentiment)
        sample["pairs"].append([aspect_term, sentiment])
        
        # Keep granular annotation info
        annotation_item = {
            "aspect": aspect_term,
            "sentiment": sentiment,
            "span": [start_char, end_char],
            "raw_row_id": row_id
        }
        sample["annotations"].append(annotation_item)
        
        # Teacher reasoning slot placeholder for this aspect:
        # Ri = {ET, EV, A, N, C, D} with strict ontology and counterfactual formulation
        reasoning_unit = {
            "aspect": aspect_term,
            "span": [start_char, end_char],
            "text_evidence": None,        # ET: Textual clue for sentiment
            "visual_evidence": None,      # EV: Visual clue / region description ("none" if irrelevant)
            "alignment": None,            # A: enum in ["direct", "complementary", "irrelevant", "conflict"]
            "conflict": None,             # C (flag): bool (True / False)
            "conflict_type": None,        # C (type): enum in ["none", "text_visual", "sarcasm", "intra_text"]
            "visual_necessity": None,     # N (counterfactual): int/bool (1 if P_text fails while P_full succeeds, else 0)
            "visual_delta": None,         # Delta: float (P_full(y) - P_text(y))
            "teacher_sentiment": None,    # s_hat: Teacher predicted sentiment (generated WITHOUT seeing gold sentiment)
            "is_consistent": None         # Validation flag: bool (s_hat == gold_sentiment)
        }
        sample["reasoning_units"].append(reasoning_unit)
    
    # Save to jsonl
    os.makedirs(output_dir, exist_ok=True)
    out_file = os.path.join(output_dir, f"{dataset_name}_{split}.jsonl")
    
    with open(out_file, 'w', encoding='utf-8') as f:
        for s in samples.values():
            f.write(json.dumps(s, ensure_ascii=False) + '\n')
            
    print(f"[{dataset_name.upper()} - {split}] Done: {len(data_rows)} raw aspects -> {len(samples)} grouped tweets -> {out_file}")
    return len(samples), len(data_rows)

if __name__ == '__main__':
    base = "d:/YY/MABSA-LLM/IJCAI2019_data"
    out = "d:/YY/MABSA-LLM/data/processed"
    
    total_grouped = 0
    total_raw = 0
    for ds in ['twitter2015', 'twitter2017']:
        for sp in ['train', 'dev', 'test']:
            g, r = process_split(ds, sp, base, out)
            total_grouped += g
            total_raw += r
    print(f"\nALL FINISHED: {total_raw} raw aspect entries converted into {total_grouped} multi-aspect unified samples.")
