import os
import sys
import json
import argparse
import random
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from torch.optim import AdamW
from transformers import AutoModelForImageTextToText, AutoProcessor, get_cosine_schedule_with_warmup
from peft import LoraConfig, get_peft_model
from qwen_vl_utils import process_vision_info
from tqdm import tqdm

# Include evaluator
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from evaluator import parse_model_output, compute_pair_metrics

SYSTEM_INSTRUCTION = (
    "Task: Multimodal Aspect-Based Sentiment Analysis (MABSA).\n"
    "Given the tweet and associated image, identify all aspect targets (entities or opinion targets) explicitly mentioned in the tweet and determine the sentiment polarity towards each aspect.\n"
    "Sentiment polarity must be strictly one of: ['POS', 'NEU', 'NEG'].\n"
    "Output strictly a JSON list of [aspect, sentiment] pairs. Example: [[\"target\", \"POS\"]]. If no aspect is found, output [].\n\n"
)

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

class MABSADataset(Dataset):
    def __init__(self, jsonl_path, project_root):
        self.samples = []
        self.project_root = project_root
        with open(jsonl_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    self.samples.append(json.loads(line.strip()))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        item = self.samples[idx]
        img_abs = os.path.join(self.project_root, item["image"])
        target_json = json.dumps(item["pairs"], ensure_ascii=False)
        return {
            "sample_id": item["sample_id"],
            "tweet_text": item["text"],
            "image_path": img_abs,
            "target_str": target_json,
            "ground_truth_pairs": item["pairs"]
        }

def collate_train_fn(batch, processor):
    # Process batch of size 1 (or small batch)
    item = batch[0]
    prompt = f"{SYSTEM_INSTRUCTION}Tweet: {item['tweet_text']}\nOutput:"
    
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image", "image": f"file://{item['image_path']}"},
                {"type": "text", "text": prompt}
            ]
        },
        {
            "role": "assistant",
            "content": [
                {"type": "text", "text": item["target_str"]}
            ]
        }
    ]
    
    full_text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=False)
    image_inputs, video_inputs = process_vision_info(messages)
    
    inputs = processor(
        text=[full_text],
        images=image_inputs,
        videos=video_inputs,
        padding=True,
        return_tensors="pt"
    )
    
    input_ids = inputs["input_ids"][0]
    labels = input_ids.clone()
    
    im_start_id = processor.tokenizer.convert_tokens_to_ids("<|im_start|>")
    assistant_id = processor.tokenizer.convert_tokens_to_ids("assistant")
    assistant_start_idx = -1
    for i in range(len(input_ids) - 1):
        if input_ids[i] == im_start_id and input_ids[i+1] == assistant_id:
            assistant_start_idx = i + 3
            break
            
    if assistant_start_idx != -1:
        labels[:assistant_start_idx] = -100
    else:
        labels[:] = -100  # fallback
        
    inputs["labels"] = labels.unsqueeze(0)
    return inputs

def evaluate_test_set(model, processor, test_dataset, output_preds_path, output_metrics_path, device):
    model.eval()
    all_preds = []
    all_gts = []
    records = []
    
    print(f"\n--- Running evaluation on {len(test_dataset)} test samples ---")
    with open(output_preds_path, 'w', encoding='utf-8') as f_out:
        for idx in tqdm(range(len(test_dataset)), desc="B1 Evaluation"):
            item = test_dataset[idx]
            prompt = f"{SYSTEM_INSTRUCTION}Tweet: {item['tweet_text']}\nOutput:"
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "image", "image": f"file://{item['image_path']}"},
                        {"type": "text", "text": prompt}
                    ]
                }
            ]
            
            try:
                text_input = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
                image_inputs, video_inputs = process_vision_info(messages)
                inputs = processor(
                    text=[text_input],
                    images=image_inputs,
                    videos=video_inputs,
                    padding=True,
                    return_tensors="pt"
                ).to(device)
                
                with torch.inference_mode():
                    output_ids = model.generate(
                        **inputs,
                        max_new_tokens=64,
                        do_sample=False
                    )
                generated = output_ids[:, inputs.input_ids.shape[1]:]
                raw_pred = processor.batch_decode(generated, skip_special_tokens=True)[0].strip()
            except Exception as e:
                print(f"[Warning] Error on sample {item['sample_id']}: {e}")
                raw_pred = "[]"
                
            parsed_pairs = parse_model_output(raw_pred)
            all_preds.append(parsed_pairs)
            all_gts.append(item["ground_truth_pairs"])
            
            rec = {
                "sample_id": item["sample_id"],
                "text": item["tweet_text"],
                "ground_truth_pairs": item["ground_truth_pairs"],
                "raw_output": raw_pred,
                "predicted_pairs": parsed_pairs
            }
            records.append(rec)
            f_out.write(json.dumps(rec, ensure_ascii=False) + '\n')
            f_out.flush()
            
    # 1. Overall metrics
    metrics = compute_pair_metrics(all_preds, all_gts)
    
    # 2. Empty prediction rate & avg aspect counts
    pred_counts = [len(p) for p in all_preds]
    gold_counts = [len(g) for g in all_gts]
    empty_preds = sum(1 for c in pred_counts if c == 0)
    empty_pred_rate = round((empty_preds / len(all_preds)) * 100, 2)
    avg_pred_aspects = round(sum(pred_counts) / len(pred_counts), 2)
    avg_gold_aspects = round(sum(gold_counts) / len(gold_counts), 2)
    
    metrics["empty_pred_count"] = empty_preds
    metrics["empty_pred_rate"] = empty_pred_rate
    metrics["avg_pred_aspects"] = avg_pred_aspects
    metrics["avg_gold_aspects"] = avg_gold_aspects
    
    # 3. Multi-aspect breakdown (1, 2, 3, >=4)
    breakdown = {}
    bins = {"1": [], "2": [], "3": [], ">=4": []}
    for p, g in zip(all_preds, all_gts):
        n_gold = len(g)
        k = "1" if n_gold == 1 else ("2" if n_gold == 2 else ("3" if n_gold == 3 else ">=4"))
        bins[k].append((p, g))
        
    for k, bin_items in bins.items():
        if bin_items:
            bin_preds = [item[0] for item in bin_items]
            bin_gts = [item[1] for item in bin_items]
            bin_m = compute_pair_metrics(bin_preds, bin_gts)
            breakdown[k] = {
                "count": len(bin_items),
                "aspect_recall": bin_m["aspect_recall"],
                "aspect_f1": bin_m["aspect_f1"],
                "pair_precision": bin_m["pair_precision"],
                "pair_recall": bin_m["pair_recall"],
                "pair_f1": bin_m["pair_f1"],
                "sentiment_acc": bin_m["sentiment_acc_on_matched"]
            }
            
    r_1 = breakdown.get("1", {}).get("pair_recall", 0.0)
    r_4 = breakdown.get(">=4", {}).get("pair_recall", 0.0)
    delta_r_multi = round(r_1 - r_4, 2)
    metrics["multi_aspect_breakdown"] = breakdown
    metrics["delta_r_multi"] = delta_r_multi
    
    with open(output_metrics_path, 'w', encoding='utf-8') as f:
        json.dump(metrics, f, indent=2)
        
    print(f"\n===== EVALUATION METRICS SAVED TO {output_metrics_path} =====")
    print(f"Pair Precision : {metrics['pair_precision']}%")
    print(f"Pair Recall    : {metrics['pair_recall']}%")
    print(f"Pair F1        : {metrics['pair_f1']}")
    print(f"Aspect F1      : {metrics['aspect_f1']}")
    print(f"Conditional Sent Acc: {metrics['sentiment_acc_on_matched']}%")
    print(f"Empty Pred Rate: {empty_pred_rate}% ({empty_preds}/{len(all_preds)})")
    print(f"Avg Pred/Gold Aspects: {avg_pred_aspects} / {avg_gold_aspects}")
    print(f"Delta R_multi  : {delta_r_multi} (R_1={r_1}% - R_4+={r_4}%)")
    return metrics

def train(args):
    set_seed(args.seed)
    device = f"cuda:{args.gpu_id}"
    torch.cuda.set_device(args.gpu_id)
    print(f"\n==================================================================")
    print(f"STARTING B1: Direct SFT on {args.dataset.upper()} (GPU {args.gpu_id})")
    print(f"==================================================================")
    
    # 1. Datasets
    train_file = os.path.join(args.data_dir, f"{args.dataset}_train.jsonl")
    test_file = os.path.join(args.data_dir, f"{args.dataset}_test.jsonl")
    train_ds = MABSADataset(train_file, args.project_root)
    test_ds = MABSADataset(test_file, args.project_root)
    print(f"Loaded Train: {len(train_ds)} samples, Test: {len(test_ds)} samples.")
    
    # 2. Model & Processor
    print(f"Loading base model and processor from {args.model_path} onto {device}...")
    processor = AutoProcessor.from_pretrained(args.model_path, local_files_only=True)
    model = AutoModelForImageTextToText.from_pretrained(
        args.model_path,
        torch_dtype=torch.bfloat16,
        device_map={"": args.gpu_id},
        local_files_only=True
    )
    
    # Freeze Vision
    print("Freezing vision encoder...")
    if hasattr(model, "model") and hasattr(model.model, "visual"):
        model.model.visual.requires_grad_(False)
    elif hasattr(model, "visual"):
        model.visual.requires_grad_(False)
        
    model.gradient_checkpointing_enable()
    
    # LoRA config
    print("Setting up LoRA on language attention layers...")
    lora_config = LoraConfig(
        r=args.lora_r,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
        bias="none",
        task_type="CAUSAL_LM"
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()
    
    # 3. Optimizer & Scheduler
    optimizer = AdamW(
        [p for p in model.parameters() if p.requires_grad],
        lr=args.lr,
        weight_decay=args.weight_decay
    )
    total_steps = (len(train_ds) // args.grad_accum) * args.epochs
    warmup_steps = int(total_steps * args.warmup_ratio)
    scheduler = get_cosine_schedule_with_warmup(
        optimizer,
        num_warmup_steps=warmup_steps,
        num_training_steps=total_steps
    )
    
    output_dir = os.path.join(args.output_dir, f"b1_direct_sft_{args.dataset}")
    os.makedirs(output_dir, exist_ok=True)
    log_file = os.path.join(output_dir, "train_log.txt")
    
    # 4. Training Loop
    print(f"\nTraining for {args.epochs} epochs: {total_steps} total optimizer steps (grad_accum={args.grad_accum})...")
    step_count = 0
    accum_loss = 0.0
    
    indices = list(range(len(train_ds)))
    for epoch in range(1, args.epochs + 1):
        model.train()
        random.shuffle(indices)
        pbar = tqdm(indices, desc=f"Epoch {epoch}/{args.epochs}")
        
        optimizer.zero_grad()
        for idx in pbar:
            batch = [train_ds[idx]]
            inputs = collate_train_fn(batch, processor)
            inputs = {k: v.to(device) for k, v in inputs.items()}
            
            outputs = model(**inputs)
            loss = outputs.loss / args.grad_accum
            loss.backward()
            accum_loss += loss.item() * args.grad_accum
            step_count += 1
            
            if step_count % args.grad_accum == 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad()
                
                curr_lr = scheduler.get_last_lr()[0]
                avg_loss = accum_loss / args.grad_accum
                pbar.set_postfix({"loss": f"{avg_loss:.4f}", "lr": f"{curr_lr:.2e}"})
                with open(log_file, 'a') as f_log:
                    f_log.write(f"Epoch {epoch} | Step {step_count // args.grad_accum}/{total_steps} | Loss {avg_loss:.4f} | LR {curr_lr:.2e}\n")
                accum_loss = 0.0
                
        # Save epoch checkpoint
        ckpt_dir = os.path.join(output_dir, f"checkpoint_epoch_{epoch}")
        model.save_pretrained(ckpt_dir)
        print(f"Saved checkpoint to {ckpt_dir}")
        
    print(f"\n=== Training Complete for {args.dataset.upper()}! Starting Evaluation on Test Set ===")
    out_preds_path = os.path.join(args.output_dir, f"b1_direct_sft_{args.dataset}_test_preds.jsonl")
    out_metrics_path = os.path.join(args.output_dir, f"b1_direct_sft_{args.dataset}_test_metrics.json")
    evaluate_test_set(model, processor, test_ds, out_preds_path, out_metrics_path, device)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=str, required=True, choices=["twitter2015", "twitter2017"])
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--grad_accum", type=int, default=8)
    parser.add_argument("--warmup_ratio", type=float, default=0.05)
    parser.add_argument("--weight_decay", type=float, default=0.01)
    parser.add_argument("--lora_r", type=int, default=16)
    parser.add_argument("--lora_alpha", type=int, default=32)
    parser.add_argument("--lora_dropout", type=float, default=0.05)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--project_root", type=str, default="/opt/data/private/MABSA-LLM")
    parser.add_argument("--model_path", type=str, default="/opt/data/private/Qwen3-VL-8B-Instruct")
    parser.add_argument("--data_dir", type=str, default="/opt/data/private/MABSA-LLM/data/processed")
    parser.add_argument("--output_dir", type=str, default="/opt/data/private/MABSA-LLM/outputs")
    args = parser.parse_args()
    
    train(args)
