import os
import sys
import time

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from run_targeted_benchmark import run_targeted_eval

print("=== GPU 0: STARTING B0 TARGET-GUIDED BENCHMARKS ===", flush=True)

# 1. B0 Targeted Text-Only on TW15
run_targeted_eval('b0', 'text_only', 'twitter2015', 'test', '/opt/data/private/Qwen3-VL-8B-Instruct', '/opt/data/private/MABSA-LLM', '/opt/data/private/MABSA-LLM/data/processed', '/opt/data/private/MABSA-LLM/outputs', 0)

# 2. B0 Targeted Text-Only on TW17
run_targeted_eval('b0', 'text_only', 'twitter2017', 'test', '/opt/data/private/Qwen3-VL-8B-Instruct', '/opt/data/private/MABSA-LLM', '/opt/data/private/MABSA-LLM/data/processed', '/opt/data/private/MABSA-LLM/outputs', 0)

# 3. B0 Targeted Multimodal on TW15
run_targeted_eval('b0', 'multimodal', 'twitter2015', 'test', '/opt/data/private/Qwen3-VL-8B-Instruct', '/opt/data/private/MABSA-LLM', '/opt/data/private/MABSA-LLM/data/processed', '/opt/data/private/MABSA-LLM/outputs', 0)

# 4. B0 Targeted Multimodal on TW17
run_targeted_eval('b0', 'multimodal', 'twitter2017', 'test', '/opt/data/private/Qwen3-VL-8B-Instruct', '/opt/data/private/MABSA-LLM', '/opt/data/private/MABSA-LLM/data/processed', '/opt/data/private/MABSA-LLM/outputs', 0)

print("=== GPU 0: ALL B0 TARGETED BENCHMARKS COMPLETE! ===", flush=True)
