"""High-Throughput CLI Runner for Active Visual Reasoning Protocol (G3).

Executes the G3 benchmark over Twitter-2015 / Twitter-2017 Test and Dev sets.
Features:
- Checkpoint resumption (skips already processed sample_id)
- Multi-threaded concurrency with safe thread-locking
- Progress bar / reporting
- Automatic invocation of G3Evaluator upon completion
- ZERO label leakage during inference

DO NOT RUN AUTOMATICALLY - WAIT FOR USER AUTHORIZATION.
"""

import os
import sys
import json
import time
import random
import argparse
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, Any, List, Set, Optional

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

try:
    from bacr.gemini_client import GeminiClient
    from bacr.pipeline import G3Pipeline
    from bacr.evaluator import G3Evaluator, print_evaluation_report
except ImportError:
    from active_visual_reasoning.gemini_client import GeminiClient
    from active_visual_reasoning.pipeline import G3Pipeline
    from active_visual_reasoning.evaluator import G3Evaluator, print_evaluation_report


def load_dataset(file_path: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
    """Loads JSONL dataset records."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Dataset file not found: {file_path}")

    records = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            records.append(json.loads(line))
            if limit and len(records) >= limit:
                break
    return records


def load_existing_sample_ids(output_file: str) -> Set[str]:
    """Reads already completed sample IDs from checkpoint file."""
    if not os.path.exists(output_file):
        return set()

    existing = set()
    with open(output_file, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            try:
                data = json.loads(line)
                sid = data.get("sample_id")
                if sid:
                    existing.add(sid)
            except Exception:
                continue
    return existing


def main():
    parser = argparse.ArgumentParser(description="Run G3 Active Visual Reasoning Benchmark.")
    parser.add_argument("--dataset", choices=["twitter2015", "twitter2017"], default="twitter2015", help="Target dataset.")
    parser.add_argument("--split", choices=["test", "dev", "train"], default="test", help="Dataset split.")
    parser.add_argument("--limit", type=int, default=None, help="Maximum number of samples to process (for debugging/pilot).")
    parser.add_argument("--concurrency", type=int, default=4, help="Concurrent worker threads (recommended: 4-6).")
    parser.add_argument("--max-queries", type=int, default=2, help="Maximum allowed visual queries per sample (default: 2).")
    parser.add_argument("--data-dir", default=os.path.join(PROJECT_ROOT, "data", "processed"), help="Processed data directory.")
    parser.add_argument("--output-dir", default=os.path.join(PROJECT_ROOT, "outputs", "g3_benchmark"), help="Output directory for predictions.")
    parser.add_argument("--image-base-dir", default=PROJECT_ROOT, help="Base directory for image paths.")
    args = parser.parse_args()

    # Resolve paths
    gold_filename = f"{args.dataset}_{args.split}.jsonl"
    gold_path = os.path.join(args.data_dir, gold_filename)

    os.makedirs(args.output_dir, exist_ok=True)
    out_filename = f"g3_max{args.max_queries}_{args.dataset}_{args.split}.jsonl"
    output_path = os.path.join(args.output_dir, out_filename)

    print("\n" + "=" * 70)
    print("      ACTIVE VISUAL REASONING (G3) BENCHMARK LAUNCHER")
    print("=" * 70)
    print(f"Dataset         : {args.dataset} ({args.split})")
    print(f"Gold Path       : {gold_path}")
    print(f"Output Path     : {output_path}")
    print(f"Concurrency     : {args.concurrency}")
    print(f"Max Queries     : {args.max_queries}")
    print(f"Sample Limit    : {args.limit or 'Full Split'}")
    print("=" * 70 + "\n")

    # Load dataset
    all_samples = load_dataset(gold_path, limit=args.limit)
    completed_ids = load_existing_sample_ids(output_path)
    pending_samples = [s for s in all_samples if s.get("sample_id") not in completed_ids]

    print(f"Total target samples : {len(all_samples)}")
    print(f"Already completed    : {len(completed_ids)}")
    print(f"Pending to process   : {len(pending_samples)}\n")

    if not pending_samples:
        print("All samples are already processed! Running evaluation directly...")
        evaluator = G3Evaluator(gold_file=gold_path)
        metrics = evaluator.evaluate_predictions(pred_file=output_path)
        print_evaluation_report(metrics)
        return

    # Initialize shared pipeline & client
    client = GeminiClient()
    pipeline = G3Pipeline(client=client)

    file_lock = threading.Lock()
    processed_count = len(completed_ids)
    total_count = len(all_samples)
    start_time = time.time()

    failed_samples: List[Dict[str, Any]] = []

    def process_single(sample: Dict[str, Any]):
        nonlocal processed_count
        sid = sample.get("sample_id", "unknown")
        time.sleep(random.uniform(0.1, 0.4))
        try:
            record = pipeline.run_sample(
                sample=sample,
                image_base_dir=args.image_base_dir,
                max_queries=args.max_queries
            )
            with file_lock:
                with open(output_path, "a", encoding="utf-8") as f_out:
                    f_out.write(json.dumps(record, ensure_ascii=False) + "\n")
                    f_out.flush()
                processed_count += 1
                elapsed = time.time() - start_time
                speed = processed_count / elapsed if elapsed > 0 else 0
                print(f"[{processed_count}/{total_count}] Success: {sid} (Queries: {record['num_visual_queries']}, Time: {elapsed:.1f}s, {speed:.2f} samples/s)")
            return True, sid
        except Exception as e:
            print(f"[ERROR] Failed processing {sid}: {e}")
            with file_lock:
                failed_samples.append(sample)
            return False, sid

    # Run thread pool
    print(f"Starting execution with {args.concurrency} concurrent threads...")
    with ThreadPoolExecutor(max_workers=args.concurrency) as executor:
        futures = {executor.submit(process_single, s): s for s in pending_samples}
        for future in as_completed(futures):
            future.result()

    # If any samples failed, perform a single-threaded retry pass
    if failed_samples:
        print(f"\n[RETRY PASS] Retrying {len(failed_samples)} failed samples sequentially...")
        for s in failed_samples:
            process_single(s)

    print("\nBenchmark inference complete! Evaluating results against gold labels...")
    if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
        print(f"[WARNING] No successful predictions written to {output_path}. Aborting evaluation.")
        return

    evaluator = G3Evaluator(gold_file=gold_path)
    metrics = evaluator.evaluate_predictions(pred_file=output_path)
    print_evaluation_report(metrics)

    # Save summary metrics JSON
    summary_path = os.path.join(args.output_dir, f"metrics_{out_filename.replace('.jsonl', '.json')}")
    with open(summary_path, "w", encoding="utf-8") as f_sum:
        json.dump(metrics, f_sum, indent=2, ensure_ascii=False)
    print(f"Metrics summary saved to: {summary_path}")


if __name__ == "__main__":
    main()
