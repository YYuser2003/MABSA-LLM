"""High-Throughput Concurrent Benchmark for Gemini 3.8 Flash on Twitter-2015 and Twitter-2017 Test Sets.

Evaluates:
  Condition 1: Text-only (T -> y)
  Condition 2: Multimodal (T + I -> y)
Features:
  - Default Concurrency: 8 (proven stable on OmniRoute gateway without rate limiting)
  - Automatic model fallback (gemini_3.8 <-> antigravity/gemini-3.8-flash-tiered)
  - Robust exponential backoff retry with jitter
  - Zero label leakage
  - Only genuine successful inferences (success=True) are persisted to JSONL
  - Automatic checkpoint resume
  - Zero-dependency pure Python metric calculations
"""

import os
import sys
import json
import time
import random
import base64
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, Any, List, Optional
import requests

DEFAULT_API_KEY = os.environ.get("GEMINI_API_KEY", "sk-8155e3017561267e-0a40fe-db0a138d")
DEFAULT_BASE_URL = os.environ.get("GEMINI_BASE_URL", "http://10.60.80.119:20128")
PRIMARY_MODEL = os.environ.get("GEMINI_MODEL", "gemini_3.8")
FALLBACK_MODEL = "antigravity/gemini-3.8-flash-tiered"

PROJECT_ROOT = "D:/YY/MABSA-LLM"

TEXT_SYSTEM_PROMPT = """You are an expert aspect-based sentiment analysis assistant.
You will be given a social media tweet and a list of target aspects mentioned in it.
For EACH target aspect, classify its sentiment polarity strictly into one of: POS, NEG, NEU based STRICTLY and ONLY on the tweet text.
Output a JSON object with key "predictions" containing a list of objects:
[
  {
    "aspect": "<exact aspect text>",
    "sentiment": "POS" | "NEG" | "NEU",
    "evidence": "<brief textual evidence or rationale>"
  }
]
Output ONLY valid JSON."""

MM_SYSTEM_PROMPT = """You are an expert multimodal aspect-based sentiment analysis assistant.
You will be given a social media tweet, an image, and a list of target aspects mentioned in the tweet.
For EACH target aspect, classify its sentiment polarity strictly into one of: POS, NEG, NEU based on BOTH the tweet text and image.
Important:
- If the image contains visual sentiment cues or facial expressions toward the target aspect, incorporate them.
- If the aspect is not visible or the image is generic/unrelated background, rely on the text and do not hallucinate visual emotion.
Output a JSON object with key "predictions" containing a list of objects:
[
  {
    "aspect": "<exact aspect text>",
    "sentiment": "POS" | "NEG" | "NEU",
    "visual_present": true | false,
    "evidence": "<brief multimodal rationale>"
  }
]
Output ONLY valid JSON."""


def encode_image(image_rel_path: str) -> Optional[str]:
    full_path = os.path.join(PROJECT_ROOT, image_rel_path)
    if not os.path.exists(full_path):
        return None
    try:
        with open(full_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("utf-8")
            return f"data:image/jpeg;base64,{b64}"
    except Exception as e:
        print(f"Error reading image {full_path}: {e}")
        return None


def call_gemini_api(
    sample: Dict[str, Any],
    mode: str,
    base_url: str = DEFAULT_BASE_URL,
    api_key: str = DEFAULT_API_KEY,
    max_retries: int = 3
) -> Optional[Dict[str, Any]]:
    aspects_json = json.dumps(sample["aspects"], ensure_ascii=False)
    endpoint = base_url.rstrip("/") + "/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    if mode == "text":
        messages = [
            {"role": "system", "content": TEXT_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": f'Tweet: "{sample["text"]}"\nTarget Aspects: {aspects_json}'
            }
        ]
    else:  # multimodal
        img_url = encode_image(sample["image"])
        if not img_url:
            messages = [
                {"role": "system", "content": TEXT_SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": f'Tweet: "{sample["text"]}"\nTarget Aspects: {aspects_json}'
                }
            ]
        else:
            messages = [
                {"role": "system", "content": MM_SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": f'Tweet: "{sample["text"]}"\nTarget Aspects: {aspects_json}'
                        },
                        {
                            "type": "image_url",
                            "image_url": {"url": img_url}
                        }
                    ]
                }
            ]

    models_to_try = [PRIMARY_MODEL, FALLBACK_MODEL]

    for attempt in range(1, max_retries + 1):
        model_name = models_to_try[(attempt - 1) % len(models_to_try)]
        payload = {
            "model": model_name,
            "messages": messages,
            "response_format": {"type": "json_object"},
            "max_tokens": 1024,
            "temperature": 0.0
        }

        try:
            resp = requests.post(endpoint, headers=headers, json=payload, timeout=25)
            if resp.status_code == 200:
                data = resp.json()
                raw_response = data["choices"][0]["message"]["content"].strip()

                # Clean code fences
                clean_text = raw_response
                if clean_text.startswith("```json"):
                    clean_text = clean_text[7:]
                elif clean_text.startswith("```"):
                    clean_text = clean_text[3:]
                if clean_text.endswith("```"):
                    clean_text = clean_text[:-3]
                clean_text = clean_text.strip()

                parsed_obj = json.loads(clean_text)
                parsed_preds = []
                if isinstance(parsed_obj, dict) and "predictions" in parsed_obj:
                    parsed_preds = parsed_obj["predictions"]
                elif isinstance(parsed_obj, list):
                    parsed_preds = parsed_obj
                elif isinstance(parsed_obj, dict):
                    parsed_preds = [{"aspect": k, "sentiment": v} for k, v in parsed_obj.items()]

                # Standardize predictions format
                pred_dict = {}
                evidence_dict = {}
                vis_dict = {}
                for item in parsed_preds:
                    if isinstance(item, dict):
                        asp = str(item.get("aspect", "")).strip()
                        sent = str(item.get("sentiment", "")).upper().strip()
                        if "POS" in sent: sent = "POS"
                        elif "NEG" in sent: sent = "NEG"
                        else: sent = "NEU"
                        pred_dict[asp] = sent
                        evidence_dict[asp] = item.get("evidence", item.get("rationale", ""))
                        vis_dict[asp] = item.get("visual_present", None)

                # Ensure all target aspects are covered
                aligned_preds = []
                for asp in sample["aspects"]:
                    sent = pred_dict.get(asp, pred_dict.get(asp.lower(), "NEU"))
                    aligned_preds.append({
                        "aspect": asp,
                        "sentiment": sent,
                        "evidence": evidence_dict.get(asp, ""),
                        "visual_present": vis_dict.get(asp, None)
                    })

                return {
                    "sample_id": sample["sample_id"],
                    "dataset": sample["dataset"],
                    "split": sample["split"],
                    "mode": mode,
                    "text": sample["text"],
                    "image": sample["image"],
                    "aspects": sample["aspects"],
                    "gold_pairs": sample["pairs"],
                    "predictions": aligned_preds,
                    "raw_response": raw_response,
                    "model_used": model_name,
                    "success": True
                }

            elif resp.status_code in [429, 400, 500, 502, 503, 504]:
                wait_t = (2 ** min(attempt, 5)) + random.uniform(0.5, 2.0)
                time.sleep(wait_t)
            else:
                wait_t = 2.0
                time.sleep(wait_t)

        except Exception as e:
            wait_t = (2 ** min(attempt, 5)) + random.uniform(0.5, 2.0)
            time.sleep(wait_t)

    print(f"[!] Warning: Sample {sample['sample_id']} failed after {max_retries} attempts.")
    return None


def evaluate_predictions(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    y_true = []
    y_pred = []
    polar_true = []
    polar_pred = []

    for item in results:
        if not item or not item.get("success"):
            continue
        gold_map = dict(item["gold_pairs"])
        for pred in item["predictions"]:
            asp = pred["aspect"]
            gt = gold_map.get(asp)
            p = pred["sentiment"]
            if gt:
                y_true.append(gt)
                y_pred.append(p)
                if gt in ["POS", "NEG"]:
                    polar_true.append(gt)
                    polar_pred.append(p)

    total = len(y_true)
    if total == 0:
        return {"total_aspects": 0, "accuracy": 0.0, "macro_f1": 0.0, "polar_aspects": 0, "polar_accuracy": 0.0, "class_metrics": {}}

    correct = sum(1 for yt, yp in zip(y_true, y_pred) if yt == yp)
    acc = (correct / total) * 100.0

    polar_total = len(polar_true)
    polar_correct = sum(1 for yt, yp in zip(polar_true, polar_pred) if yt == yp)
    polar_acc = (polar_correct / polar_total) * 100.0 if polar_total > 0 else 0.0

    classes = ["POS", "NEG", "NEU"]
    f1_list = []
    class_metrics = {}
    for cls in classes:
        tp = sum(1 for yt, yp in zip(y_true, y_pred) if yt == cls and yp == cls)
        fp = sum(1 for yt, yp in zip(y_true, y_pred) if yt != cls and yp == cls)
        fn = sum(1 for yt, yp in zip(y_true, y_pred) if yt == cls and yp != cls)
        support = sum(1 for yt in y_true if yt == cls)
        prec = (tp / (tp + fp)) * 100.0 if (tp + fp) > 0 else 0.0
        rec = (tp / (tp + fn)) * 100.0 if (tp + fn) > 0 else 0.0
        f1 = (2 * prec * rec / (prec + rec)) if (prec + rec) > 0 else 0.0
        f1_list.append(f1)
        class_metrics[cls] = {
            "precision": prec,
            "recall": rec,
            "f1-score": f1,
            "support": support
        }

    macro_f1 = sum(f1_list) / len(f1_list) if f1_list else 0.0

    return {
        "total_aspects": total,
        "accuracy": acc,
        "macro_f1": macro_f1,
        "polar_aspects": polar_total,
        "polar_accuracy": polar_acc,
        "class_metrics": class_metrics
    }


def run_benchmark(
    dataset_name: str,
    mode: str,
    concurrency: int = 8,
    output_dir: str = "D:/YY/MABSA-LLM/outputs/gemini_benchmark",
    clean_restart: bool = False
) -> Dict[str, Any]:
    os.makedirs(output_dir, exist_ok=True)
    input_file = f"D:/YY/MABSA-LLM/data/processed/{dataset_name}_test.jsonl"
    output_file = os.path.join(output_dir, f"gemini38_{mode}_{dataset_name}_test.jsonl")

    if clean_restart and os.path.exists(output_file):
        os.remove(output_file)
        print(f"[{dataset_name} - {mode}] Clean restart: removed previous output file.")

    samples = []
    with open(input_file, "r", encoding="utf-8") as f:
        for line in f:
            samples.append(json.loads(line))

    completed_ids = set()
    completed_records = []
    if os.path.exists(output_file):
        with open(output_file, "r", encoding="utf-8") as f:
            for line in f:
                rec = json.loads(line)
                if rec.get("success"):
                    completed_ids.add(rec["sample_id"])
                    completed_records.append(rec)
        print(f"[{dataset_name} - {mode}] Found {len(completed_ids)} already completed successful samples. Resuming...")

    remaining = [s for s in samples if s["sample_id"] not in completed_ids]
    print(f"[{dataset_name} - {mode}] Starting benchmark on {len(remaining)} remaining samples (Total: {len(samples)}) with {concurrency} workers...")

    results = list(completed_records)
    start_time = time.time()

    with open(output_file, "a", encoding="utf-8") as out_fp:
        with ThreadPoolExecutor(max_workers=concurrency) as executor:
            future_to_sample = {
                executor.submit(call_gemini_api, sample, mode): sample
                for sample in remaining
            }

            done_count = 0
            for future in as_completed(future_to_sample):
                res = future.result()
                if res and res.get("success"):
                    results.append(res)
                    out_fp.write(json.dumps(res, ensure_ascii=False) + "\n")
                    out_fp.flush()
                done_count += 1
                if done_count % 25 == 0 or done_count == len(remaining):
                    elapsed = time.time() - start_time
                    qps = done_count / max(elapsed, 0.001)
                    print(f"[{dataset_name} - {mode}] Progress: {done_count}/{len(remaining)} ({done_count/len(remaining)*100:.1f}%) | {qps:.2f} req/s")

    metrics = evaluate_predictions(results)
    print(f"\n==========================================")
    print(f"RESULT: {dataset_name.upper()} TEST ({mode.upper()})")
    print(f"Total Aspects: {metrics['total_aspects']}")
    print(f"Accuracy:      {metrics['accuracy']:.2f}%")
    print(f"Macro-F1:      {metrics['macro_f1']:.2f}%")
    print(f"Polar Acc:     {metrics['polar_accuracy']:.2f}% (N={metrics['polar_aspects']})")
    print(f"POS F1:        {metrics['class_metrics'].get('POS', {}).get('f1-score', 0):.2f}%")
    print(f"NEG F1:        {metrics['class_metrics'].get('NEG', {}).get('f1-score', 0):.2f}%")
    print(f"NEU F1:        {metrics['class_metrics'].get('NEU', {}).get('f1-score', 0):.2f}%")
    print(f"==========================================\n")
    return metrics


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run Gemini 3.8 Flash Benchmark on MABSA Test Sets")
    parser.add_argument("--dataset", type=str, default="all", choices=["twitter2015", "twitter2017", "all"])
    parser.add_argument("--mode", type=str, default="both", choices=["text", "multimodal", "both"])
    parser.add_argument("--concurrency", type=int, default=3)
    parser.add_argument("--output_dir", type=str, default="D:/YY/MABSA-LLM/outputs/gemini_benchmark")
    parser.add_argument("--clean_restart", action="store_true", help="Delete previous outputs and restart completely")
    args = parser.parse_args()

    datasets = ["twitter2015", "twitter2017"] if args.dataset == "all" else [args.dataset]
    modes = ["text", "multimodal"] if args.mode == "both" else [args.mode]

    all_metrics = {}
    for d in datasets:
        all_metrics[d] = {}
        for m in modes:
            m_res = run_benchmark(d, m, concurrency=args.concurrency, output_dir=args.output_dir, clean_restart=args.clean_restart)
            all_metrics[d][m] = m_res

    # Save summary json
    summary_path = os.path.join(args.output_dir, "benchmark_summary.json")
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(all_metrics, f, indent=2, ensure_ascii=False)
    print(f"[+] Full metrics summary saved to: {summary_path}")

    print("\n\n" + "#" * 60)
    print("FINAL GEMINI 3.8 FLASH TEST BENCHMARK SUMMARY")
    print("#" * 60)
    for d in datasets:
        print(f"\nDataset: {d.upper()}")
        for m in modes:
            met = all_metrics[d][m]
            print(f"  - {m.upper():12s}: Acc = {met['accuracy']:.2f}%, Macro-F1 = {met['macro_f1']:.2f}%, Polar Acc = {met['polar_accuracy']:.2f}%")
        if "text" in modes and "multimodal" in modes:
            delta_acc = all_metrics[d]["multimodal"]["accuracy"] - all_metrics[d]["text"]["accuracy"]
            delta_f1 = all_metrics[d]["multimodal"]["macro_f1"] - all_metrics[d]["text"]["macro_f1"]
            print(f"  => Multimodal Uplift (Delta): Acc {delta_acc:+.2f}%, Macro-F1 {delta_f1:+.2f}%")
