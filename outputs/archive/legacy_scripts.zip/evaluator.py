import re
import json
import ast
from typing import List, Tuple, Dict, Any, Union

VALID_SENTIMENTS = {"POS", "NEU", "NEG"}
SENTIMENT_NORM_MAP = {
    "positive": "POS",
    "pos": "POS",
    "neutral": "NEU",
    "neu": "NEU",
    "negative": "NEG",
    "neg": "NEG"
}

def parse_model_output(raw_text: str) -> List[Tuple[str, str]]:
    """
    Robust parser to extract [(aspect, sentiment), ...] from model output.
    Supports JSON, Python literals, markdown fences, and regex fallbacks.
    """
    if not raw_text or not isinstance(raw_text, str):
        return []
    
    text = raw_text.strip()
    
    # 1. Strip markdown code blocks ```json ... ``` or ``` ... ```
    md_match = re.search(r'```(?:json)?\s*(.*?)\s*```', text, re.DOTALL)
    if md_match:
        text = md_match.group(1).strip()
    
    # 2. Try JSON standard parsing
    try:
        data = json.loads(text)
        if isinstance(data, list):
            pairs = []
            for item in data:
                if isinstance(item, (list, tuple)) and len(item) >= 2:
                    asp = str(item[0]).strip()
                    sent = SENTIMENT_NORM_MAP.get(str(item[1]).strip().lower(), str(item[1]).strip().upper())
                    if asp:
                        pairs.append((asp, sent))
                elif isinstance(item, dict) and "aspect" in item and "sentiment" in item:
                    asp = str(item["aspect"]).strip()
                    sent = SENTIMENT_NORM_MAP.get(str(item["sentiment"]).strip().lower(), str(item["sentiment"]).strip().upper())
                    if asp:
                        pairs.append((asp, sent))
            return pairs
    except Exception:
        pass
    
    # 3. Try Python ast.literal_eval (handles [('Chuck Bass', 'POS')])
    # Find bracketed region [...]
    bracket_match = re.search(r'\[.*\]', text, re.DOTALL)
    if bracket_match:
        bracket_text = bracket_match.group(0)
        try:
            data = ast.literal_eval(bracket_text)
            if isinstance(data, list):
                pairs = []
                for item in data:
                    if isinstance(item, (list, tuple)) and len(item) >= 2:
                        asp = str(item[0]).strip()
                        sent = SENTIMENT_NORM_MAP.get(str(item[1]).strip().lower(), str(item[1]).strip().upper())
                        if asp:
                            pairs.append((asp, sent))
                return pairs
        except Exception:
            pass

    # 4. Regex fallback: match ("aspect", "sentiment") or ['aspect', 'sentiment']
    pattern = re.compile(r'[\(\[\{]\s*[\'"]([^\'"]+?)[\'"]\s*,\s*[\'"]([a-zA-Z]+)[\'"]\s*[\)\]\}]')
    matches = pattern.findall(text)
    pairs = []
    for asp, sent in matches:
        asp = asp.strip()
        sent = SENTIMENT_NORM_MAP.get(sent.strip().lower(), sent.strip().upper())
        if asp:
            pairs.append((asp, sent))
    return pairs

def compute_pair_metrics(predictions: List[List[Tuple[str, str]]], 
                         ground_truths: List[List[Tuple[str, str]]]) -> Dict[str, float]:
    """
    Computes standard JMABSA metrics:
    - Pair Precision, Recall, Micro-F1
    - Aspect Detection Precision, Recall, Micro-F1
    - Sentiment Accuracy on correctly detected aspects
    """
    assert len(predictions) == len(ground_truths), "Preds and GTs must have same length"
    
    tp_pair = 0
    fp_pair = 0
    fn_pair = 0
    
    tp_aspect = 0
    fp_aspect = 0
    fn_aspect = 0
    
    total_matched_aspects = 0
    correct_sentiment_on_matched = 0
    
    for preds, gts in zip(predictions, ground_truths):
        # Normalize representations
        norm_preds = [(a.strip().lower(), s.strip().upper()) for a, s in preds]
        norm_gts = [(a.strip().lower(), s.strip().upper()) for a, s in gts]
        
        # 1. Aspect-Sentiment Pair Evaluation (Multi-set match)
        remaining_gt_pairs = list(norm_gts)
        for p in norm_preds:
            if p in remaining_gt_pairs:
                tp_pair += 1
                remaining_gt_pairs.remove(p)
            else:
                fp_pair += 1
        fn_pair += len(remaining_gt_pairs)
        
        # 2. Aspect Term Only Evaluation
        pred_asps = [p[0] for p in norm_preds]
        gt_asps = [g[0] for g in norm_gts]
        
        remaining_gt_asps = list(gt_asps)
        for asp in pred_asps:
            if asp in remaining_gt_asps:
                tp_aspect += 1
                remaining_gt_asps.remove(asp)
            else:
                fp_aspect += 1
        fn_aspect += len(remaining_gt_asps)
        
        # 3. Sentiment on matched aspects
        # Check for each matched aspect if sentiment matches
        matched_gt_pairs = list(norm_gts)
        for p_asp, p_sent in norm_preds:
            found_idx = -1
            for idx, (gt_asp, gt_sent) in enumerate(matched_gt_pairs):
                if p_asp == gt_asp:
                    found_idx = idx
                    break
            if found_idx != -1:
                total_matched_aspects += 1
                if p_sent == matched_gt_pairs[found_idx][1]:
                    correct_sentiment_on_matched += 1
                matched_gt_pairs.pop(found_idx)
                
    pair_p = tp_pair / (tp_pair + fp_pair) if (tp_pair + fp_pair) > 0 else 0.0
    pair_r = tp_pair / (tp_pair + fn_pair) if (tp_pair + fn_pair) > 0 else 0.0
    pair_f1 = (2 * pair_p * pair_r) / (pair_p + pair_r) if (pair_p + pair_r) > 0 else 0.0
    
    asp_p = tp_aspect / (tp_aspect + fp_aspect) if (tp_aspect + fp_aspect) > 0 else 0.0
    asp_r = tp_aspect / (tp_aspect + fn_aspect) if (tp_aspect + fn_aspect) > 0 else 0.0
    asp_f1 = (2 * asp_p * asp_r) / (asp_p + asp_r) if (asp_p + asp_r) > 0 else 0.0
    
    sent_acc = (correct_sentiment_on_matched / total_matched_aspects) if total_matched_aspects > 0 else 0.0
    
    return {
        "pair_precision": round(pair_p * 100, 2),
        "pair_recall": round(pair_r * 100, 2),
        "pair_f1": round(pair_f1 * 100, 2),
        "aspect_precision": round(asp_p * 100, 2),
        "aspect_recall": round(asp_r * 100, 2),
        "aspect_f1": round(asp_f1 * 100, 2),
        "sentiment_acc_on_matched": round(sent_acc * 100, 2),
        "tp_pair": tp_pair,
        "fp_pair": fp_pair,
        "fn_pair": fn_pair
    }

if __name__ == '__main__':
    mock_preds = [
        '[("Chuck Bass", "POS"), ("# MCM", "NEU")]',
        '```json\n[["iPhone", "positive"], ["battery", "negative"]]\n```',
        'The answer is [("camera", "POS")]'
    ]
    mock_gts = [
        [["Chuck Bass", "POS"], ["# MCM", "NEU"]],
        [["iPhone", "POS"], ["battery", "NEG"]],
        [["camera", "POS"], ["price", "NEG"]]
    ]
    parsed_preds = [parse_model_output(p) for p in mock_preds]
    metrics = compute_pair_metrics(parsed_preds, mock_gts)
    print("Self-test metrics:", json.dumps(metrics, indent=2))
