"""Master parallel launcher for all B0 & B1 Given Entity (Target-Guided) benchmarks across 3 GPUs."""

import os
import sys
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor

PYTHON_BIN = '/opt/conda/envs/qwen3vl/bin/python'
SCRIPT = '/opt/data/private/MABSA-LLM/scripts/run_targeted_benchmark.py'


def run_job(name, gpu_id, model_type, modality, dataset):
    print(f'[{name}] Starting {model_type.upper()}-{modality.upper()} on {dataset} on GPU {gpu_id}...', flush=True)
    t0 = time.time()
    cmd = [
        PYTHON_BIN, SCRIPT,
        '--model_type', model_type,
        '--modality', modality,
        '--dataset', dataset,
        '--gpu_id', str(gpu_id)
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    dt = time.time() - t0
    if res.returncode == 0:
        print(f'[{name}] COMPLETED in {dt:.1f}s!', flush=True)
        return True, name, dt, res.stdout
    else:
        print(f'[{name}] FAILED in {dt:.1f}s:\n{res.stderr[-600:]}', flush=True)
        return False, name, dt, res.stderr


def run_gpu0_b0():
    # GPU 0 handles all B0 targeted runs
    run_job('B0-Targeted-Text-TW15', 0, 'b0', 'text_only', 'twitter2015')
    run_job('B0-Targeted-Text-TW17', 0, 'b0', 'text_only', 'twitter2017')
    run_job('B0-Targeted-MM-TW15', 0, 'b0', 'multimodal', 'twitter2015')
    run_job('B0-Targeted-MM-TW17', 0, 'b0', 'multimodal', 'twitter2017')


def run_gpu1_b1_tw15():
    # GPU 1 handles B1 targeted runs for TW15
    run_job('B1-Targeted-Text-TW15', 1, 'b1', 'text_only', 'twitter2015')
    run_job('B1-Targeted-MM-TW15', 1, 'b1', 'multimodal', 'twitter2015')


def run_gpu2_b1_tw17():
    # GPU 2 handles B1 targeted runs for TW17
    run_job('B1-Targeted-Text-TW17', 2, 'b1', 'text_only', 'twitter2017')
    run_job('B1-Targeted-MM-TW17', 2, 'b1', 'multimodal', 'twitter2017')


if __name__ == '__main__':
    print('=== LAUNCHING ALL B0 & B1 TARGET-GUIDED (GIVEN ENTITIES) BENCHMARKS ACROSS 3 GPUs ===', flush=True)
    t_start = time.time()
    with ThreadPoolExecutor(max_workers=3) as executor:
        f0 = executor.submit(run_gpu0_b0)
        f1 = executor.submit(run_gpu1_b1_tw15)
        f2 = executor.submit(run_gpu2_b1_tw17)
        
        f0.result()
        f1.result()
        f2.result()
        
    total_time = time.time() - t_start
    print(f'\n=== ALL TARGET-GUIDED BENCHMARKS COMPLETED IN {total_time:.1f}s ===', flush=True)
