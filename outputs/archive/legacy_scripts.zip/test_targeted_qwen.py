import json
import torch
from transformers import AutoProcessor, AutoModelForImageTextToText
from peft import PeftModel

MODEL_DIR = '/opt/data/private/Qwen3-VL-8B-Instruct'
CKPT_DIR = '/opt/data/private/MABSA-LLM/outputs/b1_direct_sft_twitter2015/checkpoint_epoch_3'

processor = AutoProcessor.from_pretrained(MODEL_DIR, local_files_only=True)

SYSTEM_INSTRUCTION_TARGETED = (
    "Task: Targeted Sentiment Classification for MABSA.\n"
    "Given a tweet and a list of specific target aspect entities mentioned in it, "
    "classify the sentiment polarity strictly into one of: ['POS', 'NEU', 'NEG'] for EACH given target aspect.\n"
    "Output strictly a JSON list of [aspect, sentiment] pairs. Example: [[\"target\", \"POS\"]].\n"
    "Do NOT output explanations or extra text.\n\n"
)

tweet_text = "Crazy hair day ! Lydia is a contender . : )"
target_aspects = ["Lydia"]
prompt = f"{SYSTEM_INSTRUCTION_TARGETED}Tweet: {tweet_text}\nTarget Aspects: {json.dumps(target_aspects)}\nOutput:"

messages = [{'role': 'user', 'content': [{'type': 'text', 'text': prompt}]}]
text_input = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
inputs = processor(text=[text_input], padding=True, return_tensors='pt').to('cuda:0')

print('Testing Base Model B0 Targeted (Text-Only)...')
base_model = AutoModelForImageTextToText.from_pretrained(MODEL_DIR, torch_dtype=torch.bfloat16, device_map='cuda:0', local_files_only=True)
with torch.inference_mode():
    out = base_model.generate(**inputs, max_new_tokens=64, do_sample=False)
gen = out[:, inputs.input_ids.shape[1]:]
print('B0 Targeted Output:', processor.batch_decode(gen, skip_special_tokens=True)[0].strip())

print('Testing LoRA Model B1 Targeted (Text-Only)...')
lora_model = PeftModel.from_pretrained(base_model, CKPT_DIR)
with torch.inference_mode():
    out = lora_model.generate(**inputs, max_new_tokens=64, do_sample=False)
gen = out[:, inputs.input_ids.shape[1]:]
print('B1 Targeted Output:', processor.batch_decode(gen, skip_special_tokens=True)[0].strip())
print('SUCCESS!')
