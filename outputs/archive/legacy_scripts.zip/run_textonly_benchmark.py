"""Benchmark script for B0 (Zero-shot) and B1 (Direct SFT) Text-Only conditions.

Evaluates Qwen3-VL-8B-Instruct on Twitter-2015 and Twitter-2017 Test sets
without image input (pure text ablation).
Computes both:
1. JMABSA End-to-End Pair Metrics (Pair Precision, Recall, F1; Aspect F1; Matched Sent Acc)
2. TSC 3-Class Metrics (Accuracy, Macro-F1, Class-wise POS/NEG/NEU Breakdown)
"""

import os
import sys
import json
import argparse
from typing import List, Dict, Any, Tuple
import torch
from tqdm import tqdm
from transformers import AutoModelForImageTextToText, AutoProcessor
from peft import PeftModel

# Import parser and metric functions
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from evaluator import parse_model_output, compute_pair_metrics

SYSTEM_INSTRUCTION = (
    "Task: Multimodal Aspect-Based Sentiment Analysis (MABSA).\n"
    "Given the tweet and associated image, identify all aspect targets (entities or opinion targets) explicitly mentioned in the tweet and determine the sentiment polarity towards each aspect.\n"
    "Sentiment polarity must be strictly one of: ['POS', 'NEU', 'NEG'].\n"
    "Output strictly a JSON list of [aspect, sentiment] pairs. Example: [[\"target\", \"POS\"]]. If no aspect is found, output [].\n\n"
)


def compute_tsc_metrics(predictions: List[List[Tuple[str, str]]], ground_truths: List[List[Tuple[str, str]]]) -> Dict[str, Any]:
    """
    Computes 3-class sentiment metrics on:
    1. All Gold Aspects (treating undetected aspects as incorrect)
    2. Aspect-Matched Instances (measuring pure sentiment classification capability)
    """
    y_true_all = []
    y_pred_all = []
    
    y_true_matched = []
    y_pred_matched = []
    
    for preds, gts in zip(predictions, ground_truths):
        norm_preds = {p[0].strip().lower(): p[1].strip().upper() for p in preds}
        norm_gts = {g[0].strip().lower(): g[1].strip().upper() for g in gts}
        
        for asp, gold_s in norm_gts.items():
            y_true_all.append(gold_s)
            if asp in norm_preds:
                pred_s = norm_preds[asp]
                y_pred_all.append(pred_s)
                y_true_matched.append(gold_s)
                y_pred_matched.append(pred_s)
            else:
                y_pred_all.append("MISS")
                
    def calc_macro(y_t, y_p):
        if not y_t:
            return {"accuracy": 0.0, "macro_f1": 0.0, "class_metrics": {}}
        acc = sum(1 for yt, yp in zip(y_t, y_p) if yt == yp) / len(y_t) * 100.0
        classes = ["POS", "NEG", "NEU"]
        f1_list = []
        cls_dict = {}
        for cls in classes:
            tp = sum(1 for yt, yp in zip(y_t, y_p) if yt == cls and yp == cls)
            fp = sum(1 for yt, yp in zip(y_t, y_p) if yt != cls and yp == cls)
            fn = sum(1 for yt, yp in zip(y_t, y_p) if yt == cls and yp != cls)
            support = sum(1 for yt in y_t if yt == cls)
            p = (tp / (tp + fp) * 100.0) if (tp + fp) > 0 else 0.0
            r = (tp / (tp + fn) * 100.0) if (tp + fn) > 0 else 0.0
            f1 = (2 * p * r / (p + r)) if (p + r) > 0 else 0.0
            f1_list.append(f1)
            cls_dict[cls] = {"precision": round(p, 2), "recall": round(r, 2), "f1-score": round(f1, 2), "support": support}
        macro_f1 = sum(f1_list) / len(f1_list) if f1_list else 0.0
        return {
            "accuracy": round(acc, 2),
            "macro_f1": round(macro_f1, 2),
            "class_metrics": cls_dict
        }

    return {
        "all_gold_aspects_tsc": calc_macro(y_true_all, y_pred_all),
        "matched_aspects_tsc": calc_macro(y_true_matched, y_pred_matched)
    }


def run_textonly_eval(
    model_type: str,
    dataset_name: str,
    split: str,
    model_path: str,
    data_dir: str,
    output_dir: str,
    gpu_id: int,
    limit: int = None
) -> Dict[str, Any]:
    device = f"cuda:{gpu_id}" if torch.cuda.is_available() else "cpu"
    data_file = os.path.join(data_dir, f"{dataset_name}_{split}.jsonl")
    os.makedirs(output_dir, exist_ok=True)
    out_preds_file = os.path.join(output_dir, f"{model_type}_textonly_{dataset_name}_{split}_preds.jsonl")
    out_metrics_file = os.path.join(output_dir, f"{model_type}_textonly_{dataset_name}_{split}_metrics.json")
    
    print(f"\n=======================================================")
    print(f"Running {model_type.upper()} TEXT-ONLY: {dataset_name.upper()} ({split}) on {device}")
    print(f"Data input: {data_file}")
    print(f"Output preds: {out_preds_file}")
    print(f"=======================================================")
    
    # 1. Load data
    samples = []
    with open(data_file, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                samples.append(json.loads(line.strip()))
    if limit is not None and limit > 0:
        samples = samples[:limit]
    print(f"Loaded {len(samples)} samples.")
    
    # 2. Check existing cache
    cached_preds = {}
    if os.path.exists(out_preds_file):
        with open(out_preds_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    item = json.loads(line.strip())
                    cached_preds[item["sample_id"]] = item
        print(f"Found {len(cached_preds)} already evaluated samples in cache.")
        
    if len(cached_preds) < len(samples):
        print(f"Loading base processor and model from {model_path}...")
        processor = AutoProcessor.from_pretrained(model_path, local_files_only=True)
        model = AutoModelForImageTextToText.from_pretrained(
            model_path,
            torch_dtype=torch.bfloat16,
            device_map=device,
            local_files_only=True
        )
        
        if model_type == "b1":
            ckpt_path = os.path.join(output_dir, f"b1_direct_sft_{dataset_name}/checkpoint_epoch_3")
            print(f"Loading LoRA adapter for B1 from {ckpt_path}...")
            model = PeftModel.from_pretrained(model, ckpt_path)
            
        model.eval()
        
        with open(out_preds_file, 'a', encoding='utf-8') as f_out:
            for sample in tqdm(samples, desc=f"{model_type.upper()}-TextOnly-{dataset_name}"):
                sample_id = sample["sample_id"]
                if sample_id in cached_preds:
                    continue
                    
                tweet_text = sample["text"]
                prompt = f"{SYSTEM_INSTRUCTION}Tweet: {tweet_text}\nOutput:"
                messages = [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt}
                        ]
                    }
                ]
                
                try:
                    text_input = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
                    inputs = processor(
                        text=[text_input],
                        padding=True,
                        return_tensors="pt"
                    ).to(device)
                    
                    with torch.inference_mode():
                        output_ids = model.generate(
                            **inputs,
                            max_new_tokens=64,
                            do_sample=False
                        )
                    generated = output_ids[:, inputs.input_ids.shape[1]:]
                    raw_pred = processor.batch_decode(generated, skip_special_tokens=True)[0].strip()
                except Exception as e:
                    print(f"\n[Warning] Inference error on {sample_id}: {e}")
                    raw_pred = "[]"
                    
                parsed_pairs = parse_model_output(raw_pred)
                record = {
                    "sample_id": sample_id,
                    "text": tweet_text,
                    "condition": "text_only",
                    "ground_truth_pairs": sample["pairs"],
                    "raw_output": raw_pred,
                    "predicted_pairs": parsed_pairs
                }
                f_out.write(json.dumps(record, ensure_ascii=False) + '\n')
                f_out.flush()
                cached_preds[sample_id] = record

    # 3. Compute Metrics
    all_preds = []
    all_gts = []
    for s in samples:
        rec = cached_preds.get(s["sample_id"], {})
        all_preds.append(rec.get("predicted_pairs", []))
        all_gts.append(s["pairs"])
        
    pair_metrics = compute_pair_metrics(all_preds, all_gts)
    tsc_metrics = compute_tsc_metrics(all_preds, all_gts)
    
    combined_metrics = {
        "model_type": model_type,
        "condition": "text_only",
        "dataset": dataset_name,
        "split": split,
        "total_samples": len(samples),
        "pair_metrics": pair_metrics,
        "tsc_metrics": tsc_metrics
    }
    
    print(f"\n===== RESULTS for {model_type.upper()} TEXT-ONLY: {dataset_name.upper()} {split} =====")
    print(f"Pair Precision : {pair_metrics['pair_precision']}%")
    print(f"Pair Recall    : {pair_metrics['pair_recall']}%")
    print(f"Pair F1        : {pair_metrics['pair_f1']}%")
    print(f"Aspect F1      : {pair_metrics['aspect_f1']}%")
    print(f"Matched SentAcc: {pair_metrics['sentiment_acc_on_matched']}%")
    print(f"All Gold Acc   : {tsc_metrics['all_gold_aspects_tsc']['accuracy']}%")
    print(f"All Gold MF1   : {tsc_metrics['all_gold_aspects_tsc']['macro_f1']}%")
    print(f"Matched MF1    : {tsc_metrics['matched_aspects_tsc']['macro_f1']}%")
    
    with open(out_metrics_file, 'w', encoding='utf-8') as f:
        json.dump(combined_metrics, f, indent=2, ensure_ascii=False)
    print(f"Metrics saved to {out_metrics_file}\n")
    return combined_metrics


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_type", type=str, required=True, choices=["b0", "b1"])
    parser.add_argument("--dataset", type=str, required=True, choices=["twitter2015", "twitter2017"])
    parser.add_argument("--split", type=str, default="test")
    parser.add_argument("--gpu_id", type=int, default=0)
    parser.add_argument("--model_path", type=str, default="/opt/data/private/Qwen3-VL-8B-Instruct")
    parser.add_argument("--data_dir", type=str, default="/opt/data/private/MABSA-LLM/data/processed")
    parser.add_argument("--output_dir", type=str, default="/opt/data/private/MABSA-LLM/outputs")
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()
    
    run_textonly_eval(
        model_type=args.model_type,
        dataset_name=args.dataset,
        split=args.split,
        model_path=args.model_path,
        data_dir=args.data_dir,
        output_dir=args.output_dir,
        gpu_id=args.gpu_id,
        limit=args.limit
    )
