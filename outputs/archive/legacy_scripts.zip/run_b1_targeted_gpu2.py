import os
import sys
import time

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from run_targeted_benchmark import run_targeted_eval

print("=== GPU 2: STARTING B1 TARGET-GUIDED BENCHMARKS (TW17) ===", flush=True)

# 1. B1 Targeted Text-Only on TW17
run_targeted_eval('b1', 'text_only', 'twitter2017', 'test', '/opt/data/private/Qwen3-VL-8B-Instruct', '/opt/data/private/MABSA-LLM', '/opt/data/private/MABSA-LLM/data/processed', '/opt/data/private/MABSA-LLM/outputs', 2)

# 2. B1 Targeted Multimodal on TW17
run_targeted_eval('b1', 'multimodal', 'twitter2017', 'test', '/opt/data/private/Qwen3-VL-8B-Instruct', '/opt/data/private/MABSA-LLM', '/opt/data/private/MABSA-LLM/data/processed', '/opt/data/private/MABSA-LLM/outputs', 2)

print("=== GPU 2: ALL B1 TARGETED BENCHMARKS COMPLETE (TW17)! ===", flush=True)
